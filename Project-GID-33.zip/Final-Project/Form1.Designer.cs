﻿
namespace Final_Project
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.panel1 = new System.Windows.Forms.Panel();
            this.button30 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.button71 = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.Homepage = new System.Windows.Forms.TabPage();
            this.labelTime = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.StudentPortal = new System.Windows.Forms.TabPage();
            this.label10 = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.regNoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.firstNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lastNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.emailDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.contactDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dOBDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.statusDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.genderDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.studentBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dBFinalProjectDataSet8 = new Final_Project.DBFinalProjectDataSet8();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.button15 = new System.Windows.Forms.Button();
            this.button14 = new System.Windows.Forms.Button();
            this.button13 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.button12 = new System.Windows.Forms.Button();
            this.button11 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.textBox11 = new System.Windows.Forms.TextBox();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.TeacherPortal = new System.Windows.Forms.TabPage();
            this.panel6 = new System.Windows.Forms.Panel();
            this.comboBox8 = new System.Windows.Forms.ComboBox();
            this.comboBox7 = new System.Windows.Forms.ComboBox();
            this.label18 = new System.Windows.Forms.Label();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.tIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.firstNameDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lastNameDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.contactDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.emailDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.genderDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dOBDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.statusDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.teacherBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dBFinalProjectDataSet9 = new Final_Project.DBFinalProjectDataSet9();
            this.dateTimePicker2 = new System.Windows.Forms.DateTimePicker();
            this.button18 = new System.Windows.Forms.Button();
            this.button19 = new System.Windows.Forms.Button();
            this.button20 = new System.Windows.Forms.Button();
            this.button21 = new System.Windows.Forms.Button();
            this.button22 = new System.Windows.Forms.Button();
            this.button23 = new System.Windows.Forms.Button();
            this.button24 = new System.Windows.Forms.Button();
            this.textBox12 = new System.Windows.Forms.TextBox();
            this.textBox14 = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.textBox15 = new System.Windows.Forms.TextBox();
            this.textBox16 = new System.Windows.Forms.TextBox();
            this.textBox17 = new System.Windows.Forms.TextBox();
            this.label26 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.CoursePortal = new System.Windows.Forms.TabPage();
            this.panel7 = new System.Windows.Forms.Panel();
            this.label28 = new System.Windows.Forms.Label();
            this.dataGridView3 = new System.Windows.Forms.DataGridView();
            this.button25 = new System.Windows.Forms.Button();
            this.button26 = new System.Windows.Forms.Button();
            this.button27 = new System.Windows.Forms.Button();
            this.button28 = new System.Windows.Forms.Button();
            this.button29 = new System.Windows.Forms.Button();
            this.textBox19 = new System.Windows.Forms.TextBox();
            this.label34 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.textBox23 = new System.Windows.Forms.TextBox();
            this.textBox24 = new System.Windows.Forms.TextBox();
            this.label36 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.ExamPortal = new System.Windows.Forms.TabPage();
            this.label40 = new System.Windows.Forms.Label();
            this.panel8 = new System.Windows.Forms.Panel();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.dataGridView4 = new System.Windows.Forms.DataGridView();
            this.button16 = new System.Windows.Forms.Button();
            this.button17 = new System.Windows.Forms.Button();
            this.button31 = new System.Windows.Forms.Button();
            this.button32 = new System.Windows.Forms.Button();
            this.button33 = new System.Windows.Forms.Button();
            this.textBox18 = new System.Windows.Forms.TextBox();
            this.textBox20 = new System.Windows.Forms.TextBox();
            this.label30 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.textBox25 = new System.Windows.Forms.TextBox();
            this.textBox26 = new System.Windows.Forms.TextBox();
            this.textBox27 = new System.Windows.Forms.TextBox();
            this.label39 = new System.Windows.Forms.Label();
            this.TeacherSalary = new System.Windows.Forms.TabPage();
            this.label42 = new System.Windows.Forms.Label();
            this.panel9 = new System.Windows.Forms.Panel();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.label33 = new System.Windows.Forms.Label();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.label32 = new System.Windows.Forms.Label();
            this.button45 = new System.Windows.Forms.Button();
            this.label41 = new System.Windows.Forms.Label();
            this.dataGridView5 = new System.Windows.Forms.DataGridView();
            this.dateTimePicker3 = new System.Windows.Forms.DateTimePicker();
            this.button36 = new System.Windows.Forms.Button();
            this.button37 = new System.Windows.Forms.Button();
            this.button38 = new System.Windows.Forms.Button();
            this.button39 = new System.Windows.Forms.Button();
            this.button40 = new System.Windows.Forms.Button();
            this.textBox29 = new System.Windows.Forms.TextBox();
            this.label45 = new System.Windows.Forms.Label();
            this.label46 = new System.Windows.Forms.Label();
            this.textBox33 = new System.Windows.Forms.TextBox();
            this.label49 = new System.Windows.Forms.Label();
            this.TeacherAttendance = new System.Windows.Forms.TabPage();
            this.panel10 = new System.Windows.Forms.Panel();
            this.textBox31 = new System.Windows.Forms.TextBox();
            this.label87 = new System.Windows.Forms.Label();
            this.textBox22 = new System.Windows.Forms.TextBox();
            this.label86 = new System.Windows.Forms.Label();
            this.button44 = new System.Windows.Forms.Button();
            this.label50 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.dataGridView6 = new System.Windows.Forms.DataGridView();
            this.dateTimePicker4 = new System.Windows.Forms.DateTimePicker();
            this.button34 = new System.Windows.Forms.Button();
            this.button35 = new System.Windows.Forms.Button();
            this.button41 = new System.Windows.Forms.Button();
            this.button42 = new System.Windows.Forms.Button();
            this.button43 = new System.Windows.Forms.Button();
            this.textBox28 = new System.Windows.Forms.TextBox();
            this.textBox30 = new System.Windows.Forms.TextBox();
            this.label51 = new System.Windows.Forms.Label();
            this.label54 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.StudentFee = new System.Windows.Forms.TabPage();
            this.label62 = new System.Windows.Forms.Label();
            this.panel11 = new System.Windows.Forms.Panel();
            this.comboBox4 = new System.Windows.Forms.ComboBox();
            this.comboBox3 = new System.Windows.Forms.ComboBox();
            this.button62 = new System.Windows.Forms.Button();
            this.dateTimePicker6 = new System.Windows.Forms.DateTimePicker();
            this.label52 = new System.Windows.Forms.Label();
            this.dataGridView7 = new System.Windows.Forms.DataGridView();
            this.dateTimePicker5 = new System.Windows.Forms.DateTimePicker();
            this.button50 = new System.Windows.Forms.Button();
            this.button51 = new System.Windows.Forms.Button();
            this.button52 = new System.Windows.Forms.Button();
            this.button53 = new System.Windows.Forms.Button();
            this.button54 = new System.Windows.Forms.Button();
            this.label53 = new System.Windows.Forms.Label();
            this.label58 = new System.Windows.Forms.Label();
            this.label59 = new System.Windows.Forms.Label();
            this.label60 = new System.Windows.Forms.Label();
            this.textBox40 = new System.Windows.Forms.TextBox();
            this.label61 = new System.Windows.Forms.Label();
            this.StudentResult = new System.Windows.Forms.TabPage();
            this.panel12 = new System.Windows.Forms.Panel();
            this.textBox21 = new System.Windows.Forms.TextBox();
            this.label82 = new System.Windows.Forms.Label();
            this.button63 = new System.Windows.Forms.Button();
            this.label56 = new System.Windows.Forms.Label();
            this.dataGridView8 = new System.Windows.Forms.DataGridView();
            this.button55 = new System.Windows.Forms.Button();
            this.button56 = new System.Windows.Forms.Button();
            this.button57 = new System.Windows.Forms.Button();
            this.button58 = new System.Windows.Forms.Button();
            this.button59 = new System.Windows.Forms.Button();
            this.textBox36 = new System.Windows.Forms.TextBox();
            this.textBox37 = new System.Windows.Forms.TextBox();
            this.textBox39 = new System.Windows.Forms.TextBox();
            this.label63 = new System.Windows.Forms.Label();
            this.label65 = new System.Windows.Forms.Label();
            this.label66 = new System.Windows.Forms.Label();
            this.label67 = new System.Windows.Forms.Label();
            this.label68 = new System.Windows.Forms.Label();
            this.textBox41 = new System.Windows.Forms.TextBox();
            this.textBox42 = new System.Windows.Forms.TextBox();
            this.textBox43 = new System.Windows.Forms.TextBox();
            this.label69 = new System.Windows.Forms.Label();
            this.label55 = new System.Windows.Forms.Label();
            this.StudentAttendance = new System.Windows.Forms.TabPage();
            this.panel13 = new System.Windows.Forms.Panel();
            this.comboBox10 = new System.Windows.Forms.ComboBox();
            this.comboBox9 = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.comboBox6 = new System.Windows.Forms.ComboBox();
            this.comboBox5 = new System.Windows.Forms.ComboBox();
            this.label73 = new System.Windows.Forms.Label();
            this.button46 = new System.Windows.Forms.Button();
            this.label64 = new System.Windows.Forms.Label();
            this.label70 = new System.Windows.Forms.Label();
            this.dataGridView9 = new System.Windows.Forms.DataGridView();
            this.dateTimePicker7 = new System.Windows.Forms.DateTimePicker();
            this.button47 = new System.Windows.Forms.Button();
            this.button48 = new System.Windows.Forms.Button();
            this.button49 = new System.Windows.Forms.Button();
            this.button60 = new System.Windows.Forms.Button();
            this.button61 = new System.Windows.Forms.Button();
            this.label71 = new System.Windows.Forms.Label();
            this.label57 = new System.Windows.Forms.Label();
            this.StudentClass = new System.Windows.Forms.TabPage();
            this.panel14 = new System.Windows.Forms.Panel();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.button70 = new System.Windows.Forms.Button();
            this.button64 = new System.Windows.Forms.Button();
            this.label75 = new System.Windows.Forms.Label();
            this.dataGridView10 = new System.Windows.Forms.DataGridView();
            this.button65 = new System.Windows.Forms.Button();
            this.button66 = new System.Windows.Forms.Button();
            this.button67 = new System.Windows.Forms.Button();
            this.button68 = new System.Windows.Forms.Button();
            this.button69 = new System.Windows.Forms.Button();
            this.textBox46 = new System.Windows.Forms.TextBox();
            this.textBox47 = new System.Windows.Forms.TextBox();
            this.label76 = new System.Windows.Forms.Label();
            this.label78 = new System.Windows.Forms.Label();
            this.label79 = new System.Windows.Forms.Label();
            this.textBox48 = new System.Windows.Forms.TextBox();
            this.textBox49 = new System.Windows.Forms.TextBox();
            this.label80 = new System.Windows.Forms.Label();
            this.label74 = new System.Windows.Forms.Label();
            this.Section = new System.Windows.Forms.TabPage();
            this.panel15 = new System.Windows.Forms.Panel();
            this.textBox13 = new System.Windows.Forms.TextBox();
            this.label72 = new System.Windows.Forms.Label();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.label48 = new System.Windows.Forms.Label();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.label47 = new System.Windows.Forms.Label();
            this.button72 = new System.Windows.Forms.Button();
            this.label81 = new System.Windows.Forms.Label();
            this.dataGridView11 = new System.Windows.Forms.DataGridView();
            this.button73 = new System.Windows.Forms.Button();
            this.button74 = new System.Windows.Forms.Button();
            this.button75 = new System.Windows.Forms.Button();
            this.button76 = new System.Windows.Forms.Button();
            this.button77 = new System.Windows.Forms.Button();
            this.textBox50 = new System.Windows.Forms.TextBox();
            this.label83 = new System.Windows.Forms.Label();
            this.label84 = new System.Windows.Forms.Label();
            this.textBox52 = new System.Windows.Forms.TextBox();
            this.textBox53 = new System.Windows.Forms.TextBox();
            this.label85 = new System.Windows.Forms.Label();
            this.label77 = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.timer2 = new System.Windows.Forms.Timer(this.components);
            this.studentTableAdapter = new Final_Project.DBFinalProjectDataSet8TableAdapters.StudentTableAdapter();
            this.teacherTableAdapter = new Final_Project.DBFinalProjectDataSet9TableAdapters.TeacherTableAdapter();
            this.button1 = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.Homepage.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.StudentPortal.SuspendLayout();
            this.panel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.studentBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dBFinalProjectDataSet8)).BeginInit();
            this.TeacherPortal.SuspendLayout();
            this.panel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.teacherBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dBFinalProjectDataSet9)).BeginInit();
            this.CoursePortal.SuspendLayout();
            this.panel7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).BeginInit();
            this.ExamPortal.SuspendLayout();
            this.panel8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView4)).BeginInit();
            this.TeacherSalary.SuspendLayout();
            this.panel9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView5)).BeginInit();
            this.TeacherAttendance.SuspendLayout();
            this.panel10.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView6)).BeginInit();
            this.StudentFee.SuspendLayout();
            this.panel11.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView7)).BeginInit();
            this.StudentResult.SuspendLayout();
            this.panel12.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView8)).BeginInit();
            this.StudentAttendance.SuspendLayout();
            this.panel13.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView9)).BeginInit();
            this.StudentClass.SuspendLayout();
            this.panel14.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView10)).BeginInit();
            this.Section.SuspendLayout();
            this.panel15.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView11)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.panel1.Controls.Add(this.button30);
            this.panel1.Controls.Add(this.button4);
            this.panel1.Controls.Add(this.button3);
            this.panel1.Controls.Add(this.button2);
            this.panel1.Controls.Add(this.button6);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(179, 496);
            this.panel1.TabIndex = 0;
            // 
            // button30
            // 
            this.button30.FlatAppearance.BorderSize = 0;
            this.button30.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button30.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button30.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button30.Image = ((System.Drawing.Image)(resources.GetObject("button30.Image")));
            this.button30.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.button30.Location = new System.Drawing.Point(3, 411);
            this.button30.Name = "button30";
            this.button30.Padding = new System.Windows.Forms.Padding(8, 0, 0, 0);
            this.button30.Size = new System.Drawing.Size(168, 40);
            this.button30.TabIndex = 11;
            this.button30.Text = "     Exam Portal";
            this.button30.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button30.UseVisualStyleBackColor = true;
            this.button30.Click += new System.EventHandler(this.button30_Click);
            // 
            // button4
            // 
            this.button4.FlatAppearance.BorderSize = 0;
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button4.Image = ((System.Drawing.Image)(resources.GetObject("button4.Image")));
            this.button4.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.button4.Location = new System.Drawing.Point(3, 338);
            this.button4.Name = "button4";
            this.button4.Padding = new System.Windows.Forms.Padding(8, 0, 0, 0);
            this.button4.Size = new System.Drawing.Size(168, 40);
            this.button4.TabIndex = 10;
            this.button4.Text = "     Course Portal";
            this.button4.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button3
            // 
            this.button3.FlatAppearance.BorderSize = 0;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button3.Image = ((System.Drawing.Image)(resources.GetObject("button3.Image")));
            this.button3.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.button3.Location = new System.Drawing.Point(3, 262);
            this.button3.Name = "button3";
            this.button3.Padding = new System.Windows.Forms.Padding(8, 0, 0, 0);
            this.button3.Size = new System.Drawing.Size(168, 40);
            this.button3.TabIndex = 9;
            this.button3.Text = "     Teacher Portal";
            this.button3.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button2
            // 
            this.button2.FlatAppearance.BorderSize = 0;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button2.Image = ((System.Drawing.Image)(resources.GetObject("button2.Image")));
            this.button2.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.button2.Location = new System.Drawing.Point(3, 195);
            this.button2.Name = "button2";
            this.button2.Padding = new System.Windows.Forms.Padding(8, 0, 0, 0);
            this.button2.Size = new System.Drawing.Size(168, 40);
            this.button2.TabIndex = 8;
            this.button2.Text = "      Student Portal";
            this.button2.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button6
            // 
            this.button6.FlatAppearance.BorderSize = 0;
            this.button6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button6.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button6.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button6.Image = ((System.Drawing.Image)(resources.GetObject("button6.Image")));
            this.button6.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.button6.Location = new System.Drawing.Point(3, 121);
            this.button6.Name = "button6";
            this.button6.Padding = new System.Windows.Forms.Padding(8, 0, 0, 0);
            this.button6.Size = new System.Drawing.Size(168, 40);
            this.button6.TabIndex = 6;
            this.button6.Text = "     Home Page";
            this.button6.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.button71);
            this.panel2.Controls.Add(this.panel3);
            this.panel2.Controls.Add(this.label2);
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(176, 80);
            this.panel2.TabIndex = 5;
            this.panel2.Paint += new System.Windows.Forms.PaintEventHandler(this.panel2_Paint);
            // 
            // button71
            // 
            this.button71.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button71.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button71.FlatAppearance.BorderSize = 0;
            this.button71.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button71.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button71.ForeColor = System.Drawing.Color.White;
            this.button71.Image = ((System.Drawing.Image)(resources.GetObject("button71.Image")));
            this.button71.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button71.Location = new System.Drawing.Point(12, 27);
            this.button71.Name = "button71";
            this.button71.Size = new System.Drawing.Size(38, 29);
            this.button71.TabIndex = 3;
            this.button71.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button71.UseVisualStyleBackColor = true;
            this.button71.Click += new System.EventHandler(this.button71_Click);
            // 
            // panel3
            // 
            this.panel3.Location = new System.Drawing.Point(198, 0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(589, 637);
            this.panel3.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label2.Location = new System.Drawing.Point(72, 31);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(54, 21);
            this.label2.TabIndex = 1;
            this.label2.Text = "Menu";
            // 
            // tabControl1
            // 
            this.tabControl1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tabControl1.Controls.Add(this.Homepage);
            this.tabControl1.Controls.Add(this.StudentPortal);
            this.tabControl1.Controls.Add(this.TeacherPortal);
            this.tabControl1.Controls.Add(this.CoursePortal);
            this.tabControl1.Controls.Add(this.ExamPortal);
            this.tabControl1.Controls.Add(this.TeacherSalary);
            this.tabControl1.Controls.Add(this.TeacherAttendance);
            this.tabControl1.Controls.Add(this.StudentFee);
            this.tabControl1.Controls.Add(this.StudentResult);
            this.tabControl1.Controls.Add(this.StudentAttendance);
            this.tabControl1.Controls.Add(this.StudentClass);
            this.tabControl1.Controls.Add(this.Section);
            this.tabControl1.Location = new System.Drawing.Point(173, -27);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(585, 523);
            this.tabControl1.TabIndex = 1;
            // 
            // Homepage
            // 
            this.Homepage.Controls.Add(this.labelTime);
            this.Homepage.Controls.Add(this.pictureBox1);
            this.Homepage.Controls.Add(this.label1);
            this.Homepage.Location = new System.Drawing.Point(4, 22);
            this.Homepage.Name = "Homepage";
            this.Homepage.Padding = new System.Windows.Forms.Padding(3);
            this.Homepage.Size = new System.Drawing.Size(577, 497);
            this.Homepage.TabIndex = 0;
            this.Homepage.Text = "tabPage1";
            this.Homepage.UseVisualStyleBackColor = true;
            this.Homepage.Click += new System.EventHandler(this.Homepage_Click);
            // 
            // labelTime
            // 
            this.labelTime.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.labelTime.AutoSize = true;
            this.labelTime.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelTime.ForeColor = System.Drawing.Color.Black;
            this.labelTime.Location = new System.Drawing.Point(240, 66);
            this.labelTime.Name = "labelTime";
            this.labelTime.Size = new System.Drawing.Size(83, 19);
            this.labelTime.TabIndex = 2;
            this.labelTime.Text = "HH:MM:SS";
            this.labelTime.Click += new System.EventHandler(this.labelTime_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(77, 96);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(448, 370);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Poppins Black", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(66, 11);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(447, 65);
            this.label1.TabIndex = 0;
            this.label1.Text = "Aspen Heights School";
            this.label1.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // StudentPortal
            // 
            this.StudentPortal.Controls.Add(this.label10);
            this.StudentPortal.Controls.Add(this.panel5);
            this.StudentPortal.Location = new System.Drawing.Point(4, 22);
            this.StudentPortal.Name = "StudentPortal";
            this.StudentPortal.Padding = new System.Windows.Forms.Padding(3);
            this.StudentPortal.Size = new System.Drawing.Size(577, 497);
            this.StudentPortal.TabIndex = 2;
            this.StudentPortal.Text = "tabPage1";
            this.StudentPortal.UseVisualStyleBackColor = true;
            // 
            // label10
            // 
            this.label10.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.Transparent;
            this.label10.Font = new System.Drawing.Font("Poppins Black", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label10.Location = new System.Drawing.Point(172, 5);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(226, 48);
            this.label10.TabIndex = 8;
            this.label10.Text = "Student Portal";
            this.label10.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // panel5
            // 
            this.panel5.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panel5.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.panel5.Controls.Add(this.button1);
            this.panel5.Controls.Add(this.comboBox2);
            this.panel5.Controls.Add(this.comboBox1);
            this.panel5.Controls.Add(this.label13);
            this.panel5.Controls.Add(this.label7);
            this.panel5.Controls.Add(this.dataGridView1);
            this.panel5.Controls.Add(this.dateTimePicker1);
            this.panel5.Controls.Add(this.button15);
            this.panel5.Controls.Add(this.button14);
            this.panel5.Controls.Add(this.button13);
            this.panel5.Controls.Add(this.button8);
            this.panel5.Controls.Add(this.button12);
            this.panel5.Controls.Add(this.button11);
            this.panel5.Controls.Add(this.button10);
            this.panel5.Controls.Add(this.button9);
            this.panel5.Controls.Add(this.button7);
            this.panel5.Controls.Add(this.textBox11);
            this.panel5.Controls.Add(this.textBox8);
            this.panel5.Controls.Add(this.textBox7);
            this.panel5.Controls.Add(this.label17);
            this.panel5.Controls.Add(this.label16);
            this.panel5.Controls.Add(this.label15);
            this.panel5.Controls.Add(this.label14);
            this.panel5.Controls.Add(this.label12);
            this.panel5.Controls.Add(this.label11);
            this.panel5.Controls.Add(this.textBox5);
            this.panel5.Controls.Add(this.textBox6);
            this.panel5.Controls.Add(this.label9);
            this.panel5.Location = new System.Drawing.Point(3, 56);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(577, 441);
            this.panel5.TabIndex = 7;
            this.panel5.Paint += new System.Windows.Forms.PaintEventHandler(this.panel5_Paint);
            // 
            // comboBox2
            // 
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Location = new System.Drawing.Point(129, 363);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(104, 21);
            this.comboBox2.TabIndex = 37;
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(129, 331);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(104, 21);
            this.comboBox1.TabIndex = 36;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(17, 332);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(49, 20);
            this.label13.TabIndex = 35;
            this.label13.Text = "Status";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(374, 79);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(80, 20);
            this.label7.TabIndex = 33;
            this.label7.Text = "Table View";
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.BackgroundColor = System.Drawing.SystemColors.Control;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.regNoDataGridViewTextBoxColumn,
            this.firstNameDataGridViewTextBoxColumn,
            this.lastNameDataGridViewTextBoxColumn,
            this.emailDataGridViewTextBoxColumn,
            this.contactDataGridViewTextBoxColumn,
            this.dOBDataGridViewTextBoxColumn,
            this.statusDataGridViewTextBoxColumn,
            this.genderDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.studentBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(261, 107);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(310, 179);
            this.dataGridView1.TabIndex = 32;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick_1);
            // 
            // regNoDataGridViewTextBoxColumn
            // 
            this.regNoDataGridViewTextBoxColumn.DataPropertyName = "RegNo";
            this.regNoDataGridViewTextBoxColumn.HeaderText = "RegNo";
            this.regNoDataGridViewTextBoxColumn.Name = "regNoDataGridViewTextBoxColumn";
            // 
            // firstNameDataGridViewTextBoxColumn
            // 
            this.firstNameDataGridViewTextBoxColumn.DataPropertyName = "FirstName";
            this.firstNameDataGridViewTextBoxColumn.HeaderText = "FirstName";
            this.firstNameDataGridViewTextBoxColumn.Name = "firstNameDataGridViewTextBoxColumn";
            // 
            // lastNameDataGridViewTextBoxColumn
            // 
            this.lastNameDataGridViewTextBoxColumn.DataPropertyName = "LastName";
            this.lastNameDataGridViewTextBoxColumn.HeaderText = "LastName";
            this.lastNameDataGridViewTextBoxColumn.Name = "lastNameDataGridViewTextBoxColumn";
            // 
            // emailDataGridViewTextBoxColumn
            // 
            this.emailDataGridViewTextBoxColumn.DataPropertyName = "Email";
            this.emailDataGridViewTextBoxColumn.HeaderText = "Email";
            this.emailDataGridViewTextBoxColumn.Name = "emailDataGridViewTextBoxColumn";
            // 
            // contactDataGridViewTextBoxColumn
            // 
            this.contactDataGridViewTextBoxColumn.DataPropertyName = "Contact";
            this.contactDataGridViewTextBoxColumn.HeaderText = "Contact";
            this.contactDataGridViewTextBoxColumn.Name = "contactDataGridViewTextBoxColumn";
            // 
            // dOBDataGridViewTextBoxColumn
            // 
            this.dOBDataGridViewTextBoxColumn.DataPropertyName = "DOB";
            this.dOBDataGridViewTextBoxColumn.HeaderText = "DOB";
            this.dOBDataGridViewTextBoxColumn.Name = "dOBDataGridViewTextBoxColumn";
            // 
            // statusDataGridViewTextBoxColumn
            // 
            this.statusDataGridViewTextBoxColumn.DataPropertyName = "Status";
            this.statusDataGridViewTextBoxColumn.HeaderText = "Status";
            this.statusDataGridViewTextBoxColumn.Name = "statusDataGridViewTextBoxColumn";
            // 
            // genderDataGridViewTextBoxColumn
            // 
            this.genderDataGridViewTextBoxColumn.DataPropertyName = "Gender";
            this.genderDataGridViewTextBoxColumn.HeaderText = "Gender";
            this.genderDataGridViewTextBoxColumn.Name = "genderDataGridViewTextBoxColumn";
            // 
            // studentBindingSource
            // 
            this.studentBindingSource.DataMember = "Student";
            this.studentBindingSource.DataSource = this.dBFinalProjectDataSet8;
            // 
            // dBFinalProjectDataSet8
            // 
            this.dBFinalProjectDataSet8.DataSetName = "DBFinalProjectDataSet8";
            this.dBFinalProjectDataSet8.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(100, 292);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(201, 20);
            this.dateTimePicker1.TabIndex = 31;
            // 
            // button15
            // 
            this.button15.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button15.BackColor = System.Drawing.SystemColors.ControlText;
            this.button15.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button15.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button15.Location = new System.Drawing.Point(415, 16);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(110, 23);
            this.button15.TabIndex = 30;
            this.button15.Text = "Student Class";
            this.button15.UseVisualStyleBackColor = false;
            this.button15.Click += new System.EventHandler(this.button15_Click);
            // 
            // button14
            // 
            this.button14.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button14.BackColor = System.Drawing.SystemColors.ControlText;
            this.button14.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button14.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button14.Location = new System.Drawing.Point(141, 16);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(104, 23);
            this.button14.TabIndex = 29;
            this.button14.Text = "Student Result";
            this.button14.UseVisualStyleBackColor = false;
            this.button14.Click += new System.EventHandler(this.button14_Click);
            // 
            // button13
            // 
            this.button13.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button13.BackColor = System.Drawing.SystemColors.ControlText;
            this.button13.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button13.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button13.Location = new System.Drawing.Point(267, 16);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(129, 23);
            this.button13.TabIndex = 28;
            this.button13.Text = "Student Attendance";
            this.button13.UseVisualStyleBackColor = false;
            this.button13.Click += new System.EventHandler(this.button13_Click);
            // 
            // button8
            // 
            this.button8.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button8.BackColor = System.Drawing.SystemColors.ControlText;
            this.button8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button8.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button8.Location = new System.Drawing.Point(21, 16);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(104, 23);
            this.button8.TabIndex = 27;
            this.button8.Text = "Student Fee";
            this.button8.UseVisualStyleBackColor = false;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // button12
            // 
            this.button12.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button12.BackColor = System.Drawing.SystemColors.ControlText;
            this.button12.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button12.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button12.Location = new System.Drawing.Point(132, 397);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(75, 23);
            this.button12.TabIndex = 26;
            this.button12.Text = "Update";
            this.button12.UseVisualStyleBackColor = false;
            this.button12.Click += new System.EventHandler(this.button12_Click);
            // 
            // button11
            // 
            this.button11.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button11.BackColor = System.Drawing.SystemColors.ControlText;
            this.button11.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button11.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button11.Location = new System.Drawing.Point(238, 397);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(75, 23);
            this.button11.TabIndex = 25;
            this.button11.Text = "Delete";
            this.button11.UseVisualStyleBackColor = false;
            this.button11.Click += new System.EventHandler(this.button11_Click);
            // 
            // button10
            // 
            this.button10.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button10.BackColor = System.Drawing.SystemColors.ControlText;
            this.button10.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button10.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button10.Location = new System.Drawing.Point(335, 397);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(75, 23);
            this.button10.TabIndex = 24;
            this.button10.Text = "Search";
            this.button10.UseVisualStyleBackColor = false;
            this.button10.Click += new System.EventHandler(this.button10_Click);
            // 
            // button9
            // 
            this.button9.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button9.BackColor = System.Drawing.SystemColors.ControlText;
            this.button9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button9.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button9.Location = new System.Drawing.Point(438, 397);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(75, 23);
            this.button9.TabIndex = 23;
            this.button9.Text = "Show";
            this.button9.UseVisualStyleBackColor = false;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // button7
            // 
            this.button7.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button7.BackColor = System.Drawing.SystemColors.ControlText;
            this.button7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button7.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button7.Location = new System.Drawing.Point(21, 397);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(75, 23);
            this.button7.TabIndex = 21;
            this.button7.Text = "Insert";
            this.button7.UseVisualStyleBackColor = false;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // textBox11
            // 
            this.textBox11.Location = new System.Drawing.Point(129, 61);
            this.textBox11.Name = "textBox11";
            this.textBox11.Size = new System.Drawing.Size(104, 20);
            this.textBox11.TabIndex = 20;
            // 
            // textBox8
            // 
            this.textBox8.Location = new System.Drawing.Point(129, 248);
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(104, 20);
            this.textBox8.TabIndex = 17;
            // 
            // textBox7
            // 
            this.textBox7.Location = new System.Drawing.Point(129, 198);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(104, 20);
            this.textBox7.TabIndex = 16;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(21, 292);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(38, 20);
            this.label17.TabIndex = 15;
            this.label17.Text = "Dob";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(21, 196);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(46, 20);
            this.label16.TabIndex = 14;
            this.label16.Text = "Email";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(17, 364);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(57, 20);
            this.label15.TabIndex = 13;
            this.label15.Text = "Gender";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(21, 246);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(60, 20);
            this.label14.TabIndex = 12;
            this.label14.Text = "Contact";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(15, 145);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(79, 20);
            this.label12.TabIndex = 10;
            this.label12.Text = "Last Name";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(15, 102);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(80, 20);
            this.label11.TabIndex = 9;
            this.label11.Text = "First Name";
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(129, 147);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(104, 20);
            this.textBox5.TabIndex = 3;
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(129, 104);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(104, 20);
            this.textBox6.TabIndex = 1;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(17, 59);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(59, 20);
            this.label9.TabIndex = 0;
            this.label9.Text = "Reg No";
            // 
            // TeacherPortal
            // 
            this.TeacherPortal.Controls.Add(this.panel6);
            this.TeacherPortal.Controls.Add(this.label8);
            this.TeacherPortal.Location = new System.Drawing.Point(4, 22);
            this.TeacherPortal.Name = "TeacherPortal";
            this.TeacherPortal.Padding = new System.Windows.Forms.Padding(3);
            this.TeacherPortal.Size = new System.Drawing.Size(577, 497);
            this.TeacherPortal.TabIndex = 3;
            this.TeacherPortal.Text = "tabPage1";
            this.TeacherPortal.UseVisualStyleBackColor = true;
            // 
            // panel6
            // 
            this.panel6.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panel6.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.panel6.Controls.Add(this.comboBox8);
            this.panel6.Controls.Add(this.comboBox7);
            this.panel6.Controls.Add(this.label18);
            this.panel6.Controls.Add(this.dataGridView2);
            this.panel6.Controls.Add(this.dateTimePicker2);
            this.panel6.Controls.Add(this.button18);
            this.panel6.Controls.Add(this.button19);
            this.panel6.Controls.Add(this.button20);
            this.panel6.Controls.Add(this.button21);
            this.panel6.Controls.Add(this.button22);
            this.panel6.Controls.Add(this.button23);
            this.panel6.Controls.Add(this.button24);
            this.panel6.Controls.Add(this.textBox12);
            this.panel6.Controls.Add(this.textBox14);
            this.panel6.Controls.Add(this.label19);
            this.panel6.Controls.Add(this.label20);
            this.panel6.Controls.Add(this.label21);
            this.panel6.Controls.Add(this.label22);
            this.panel6.Controls.Add(this.label23);
            this.panel6.Controls.Add(this.label24);
            this.panel6.Controls.Add(this.label25);
            this.panel6.Controls.Add(this.textBox15);
            this.panel6.Controls.Add(this.textBox16);
            this.panel6.Controls.Add(this.textBox17);
            this.panel6.Controls.Add(this.label26);
            this.panel6.Location = new System.Drawing.Point(3, 56);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(577, 441);
            this.panel6.TabIndex = 10;
            // 
            // comboBox8
            // 
            this.comboBox8.FormattingEnabled = true;
            this.comboBox8.Location = new System.Drawing.Point(129, 355);
            this.comboBox8.Name = "comboBox8";
            this.comboBox8.Size = new System.Drawing.Size(107, 21);
            this.comboBox8.TabIndex = 35;
            this.comboBox8.SelectedIndexChanged += new System.EventHandler(this.comboBox8_SelectedIndexChanged);
            // 
            // comboBox7
            // 
            this.comboBox7.FormattingEnabled = true;
            this.comboBox7.Location = new System.Drawing.Point(129, 276);
            this.comboBox7.Name = "comboBox7";
            this.comboBox7.Size = new System.Drawing.Size(107, 21);
            this.comboBox7.TabIndex = 34;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(374, 79);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(80, 20);
            this.label18.TabIndex = 33;
            this.label18.Text = "Table View";
            // 
            // dataGridView2
            // 
            this.dataGridView2.AutoGenerateColumns = false;
            this.dataGridView2.BackgroundColor = System.Drawing.SystemColors.Control;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.tIDDataGridViewTextBoxColumn,
            this.firstNameDataGridViewTextBoxColumn1,
            this.lastNameDataGridViewTextBoxColumn1,
            this.contactDataGridViewTextBoxColumn1,
            this.emailDataGridViewTextBoxColumn1,
            this.genderDataGridViewTextBoxColumn1,
            this.dOBDataGridViewTextBoxColumn1,
            this.statusDataGridViewTextBoxColumn1});
            this.dataGridView2.DataSource = this.teacherBindingSource;
            this.dataGridView2.Location = new System.Drawing.Point(261, 133);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.Size = new System.Drawing.Size(310, 179);
            this.dataGridView2.TabIndex = 32;
            this.dataGridView2.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView2_CellContentClick);
            // 
            // tIDDataGridViewTextBoxColumn
            // 
            this.tIDDataGridViewTextBoxColumn.DataPropertyName = "TID";
            this.tIDDataGridViewTextBoxColumn.HeaderText = "TID";
            this.tIDDataGridViewTextBoxColumn.Name = "tIDDataGridViewTextBoxColumn";
            // 
            // firstNameDataGridViewTextBoxColumn1
            // 
            this.firstNameDataGridViewTextBoxColumn1.DataPropertyName = "FirstName";
            this.firstNameDataGridViewTextBoxColumn1.HeaderText = "FirstName";
            this.firstNameDataGridViewTextBoxColumn1.Name = "firstNameDataGridViewTextBoxColumn1";
            // 
            // lastNameDataGridViewTextBoxColumn1
            // 
            this.lastNameDataGridViewTextBoxColumn1.DataPropertyName = "LastName";
            this.lastNameDataGridViewTextBoxColumn1.HeaderText = "LastName";
            this.lastNameDataGridViewTextBoxColumn1.Name = "lastNameDataGridViewTextBoxColumn1";
            // 
            // contactDataGridViewTextBoxColumn1
            // 
            this.contactDataGridViewTextBoxColumn1.DataPropertyName = "Contact";
            this.contactDataGridViewTextBoxColumn1.HeaderText = "Contact";
            this.contactDataGridViewTextBoxColumn1.Name = "contactDataGridViewTextBoxColumn1";
            // 
            // emailDataGridViewTextBoxColumn1
            // 
            this.emailDataGridViewTextBoxColumn1.DataPropertyName = "Email";
            this.emailDataGridViewTextBoxColumn1.HeaderText = "Email";
            this.emailDataGridViewTextBoxColumn1.Name = "emailDataGridViewTextBoxColumn1";
            // 
            // genderDataGridViewTextBoxColumn1
            // 
            this.genderDataGridViewTextBoxColumn1.DataPropertyName = "Gender";
            this.genderDataGridViewTextBoxColumn1.HeaderText = "Gender";
            this.genderDataGridViewTextBoxColumn1.Name = "genderDataGridViewTextBoxColumn1";
            // 
            // dOBDataGridViewTextBoxColumn1
            // 
            this.dOBDataGridViewTextBoxColumn1.DataPropertyName = "DOB";
            this.dOBDataGridViewTextBoxColumn1.HeaderText = "DOB";
            this.dOBDataGridViewTextBoxColumn1.Name = "dOBDataGridViewTextBoxColumn1";
            // 
            // statusDataGridViewTextBoxColumn1
            // 
            this.statusDataGridViewTextBoxColumn1.DataPropertyName = "Status";
            this.statusDataGridViewTextBoxColumn1.HeaderText = "Status";
            this.statusDataGridViewTextBoxColumn1.Name = "statusDataGridViewTextBoxColumn1";
            // 
            // teacherBindingSource
            // 
            this.teacherBindingSource.DataMember = "Teacher";
            this.teacherBindingSource.DataSource = this.dBFinalProjectDataSet9;
            // 
            // dBFinalProjectDataSet9
            // 
            this.dBFinalProjectDataSet9.DataSetName = "DBFinalProjectDataSet9";
            this.dBFinalProjectDataSet9.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // dateTimePicker2
            // 
            this.dateTimePicker2.Location = new System.Drawing.Point(129, 319);
            this.dateTimePicker2.Name = "dateTimePicker2";
            this.dateTimePicker2.Size = new System.Drawing.Size(107, 20);
            this.dateTimePicker2.TabIndex = 31;
            // 
            // button18
            // 
            this.button18.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button18.BackColor = System.Drawing.SystemColors.ControlText;
            this.button18.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button18.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button18.Location = new System.Drawing.Point(159, 16);
            this.button18.Name = "button18";
            this.button18.Size = new System.Drawing.Size(129, 23);
            this.button18.TabIndex = 28;
            this.button18.Text = "Teacher Attendance";
            this.button18.UseVisualStyleBackColor = false;
            this.button18.Click += new System.EventHandler(this.button18_Click);
            // 
            // button19
            // 
            this.button19.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button19.BackColor = System.Drawing.SystemColors.ControlText;
            this.button19.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button19.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button19.Location = new System.Drawing.Point(21, 16);
            this.button19.Name = "button19";
            this.button19.Size = new System.Drawing.Size(104, 23);
            this.button19.TabIndex = 27;
            this.button19.Text = "Teacher Salary";
            this.button19.UseVisualStyleBackColor = false;
            this.button19.Click += new System.EventHandler(this.button19_Click);
            // 
            // button20
            // 
            this.button20.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button20.BackColor = System.Drawing.SystemColors.ControlText;
            this.button20.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button20.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button20.Location = new System.Drawing.Point(132, 397);
            this.button20.Name = "button20";
            this.button20.Size = new System.Drawing.Size(75, 23);
            this.button20.TabIndex = 26;
            this.button20.Text = "Update";
            this.button20.UseVisualStyleBackColor = false;
            this.button20.Click += new System.EventHandler(this.button20_Click);
            // 
            // button21
            // 
            this.button21.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button21.BackColor = System.Drawing.SystemColors.ControlText;
            this.button21.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button21.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button21.Location = new System.Drawing.Point(238, 397);
            this.button21.Name = "button21";
            this.button21.Size = new System.Drawing.Size(75, 23);
            this.button21.TabIndex = 25;
            this.button21.Text = "Delete";
            this.button21.UseVisualStyleBackColor = false;
            this.button21.Click += new System.EventHandler(this.button21_Click);
            // 
            // button22
            // 
            this.button22.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button22.BackColor = System.Drawing.SystemColors.ControlText;
            this.button22.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button22.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button22.Location = new System.Drawing.Point(335, 397);
            this.button22.Name = "button22";
            this.button22.Size = new System.Drawing.Size(75, 23);
            this.button22.TabIndex = 24;
            this.button22.Text = "Search";
            this.button22.UseVisualStyleBackColor = false;
            this.button22.Click += new System.EventHandler(this.button22_Click);
            // 
            // button23
            // 
            this.button23.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button23.BackColor = System.Drawing.SystemColors.ControlText;
            this.button23.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button23.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button23.Location = new System.Drawing.Point(438, 397);
            this.button23.Name = "button23";
            this.button23.Size = new System.Drawing.Size(75, 23);
            this.button23.TabIndex = 23;
            this.button23.Text = "Show";
            this.button23.UseVisualStyleBackColor = false;
            this.button23.Click += new System.EventHandler(this.button23_Click);
            // 
            // button24
            // 
            this.button24.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button24.BackColor = System.Drawing.SystemColors.ControlText;
            this.button24.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button24.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button24.Location = new System.Drawing.Point(21, 397);
            this.button24.Name = "button24";
            this.button24.Size = new System.Drawing.Size(75, 23);
            this.button24.TabIndex = 21;
            this.button24.Text = "Insert";
            this.button24.UseVisualStyleBackColor = false;
            this.button24.Click += new System.EventHandler(this.button24_Click);
            // 
            // textBox12
            // 
            this.textBox12.Location = new System.Drawing.Point(129, 61);
            this.textBox12.Name = "textBox12";
            this.textBox12.Size = new System.Drawing.Size(104, 20);
            this.textBox12.TabIndex = 20;
            // 
            // textBox14
            // 
            this.textBox14.Location = new System.Drawing.Point(129, 228);
            this.textBox14.Name = "textBox14";
            this.textBox14.Size = new System.Drawing.Size(107, 20);
            this.textBox14.TabIndex = 16;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(21, 315);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(38, 20);
            this.label19.TabIndex = 15;
            this.label19.Text = "Dob";
            this.label19.Click += new System.EventHandler(this.label19_Click);
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(21, 228);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(46, 20);
            this.label20.TabIndex = 14;
            this.label20.Text = "Email";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(20, 274);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(57, 20);
            this.label21.TabIndex = 13;
            this.label21.Text = "Gender";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(17, 188);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(60, 20);
            this.label22.TabIndex = 12;
            this.label22.Text = "Contact";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(21, 353);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(49, 20);
            this.label23.TabIndex = 11;
            this.label23.Text = "Status";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.Location = new System.Drawing.Point(15, 145);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(79, 20);
            this.label24.TabIndex = 10;
            this.label24.Text = "Last Name";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.Location = new System.Drawing.Point(15, 102);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(80, 20);
            this.label25.TabIndex = 9;
            this.label25.Text = "First Name";
            // 
            // textBox15
            // 
            this.textBox15.Location = new System.Drawing.Point(129, 188);
            this.textBox15.Name = "textBox15";
            this.textBox15.Size = new System.Drawing.Size(107, 20);
            this.textBox15.TabIndex = 5;
            // 
            // textBox16
            // 
            this.textBox16.Location = new System.Drawing.Point(129, 147);
            this.textBox16.Name = "textBox16";
            this.textBox16.Size = new System.Drawing.Size(107, 20);
            this.textBox16.TabIndex = 3;
            // 
            // textBox17
            // 
            this.textBox17.Location = new System.Drawing.Point(129, 104);
            this.textBox17.Name = "textBox17";
            this.textBox17.Size = new System.Drawing.Size(104, 20);
            this.textBox17.TabIndex = 1;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.Location = new System.Drawing.Point(17, 59);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(30, 20);
            this.label26.TabIndex = 0;
            this.label26.Text = "TId";
            // 
            // label8
            // 
            this.label8.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.Transparent;
            this.label8.Font = new System.Drawing.Font("Poppins Black", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label8.Location = new System.Drawing.Point(168, 14);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(229, 48);
            this.label8.TabIndex = 9;
            this.label8.Text = "Teacher Portal";
            this.label8.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // CoursePortal
            // 
            this.CoursePortal.Controls.Add(this.panel7);
            this.CoursePortal.Controls.Add(this.label27);
            this.CoursePortal.Location = new System.Drawing.Point(4, 22);
            this.CoursePortal.Name = "CoursePortal";
            this.CoursePortal.Padding = new System.Windows.Forms.Padding(3);
            this.CoursePortal.Size = new System.Drawing.Size(577, 497);
            this.CoursePortal.TabIndex = 4;
            this.CoursePortal.Text = "tabPage1";
            this.CoursePortal.UseVisualStyleBackColor = true;
            // 
            // panel7
            // 
            this.panel7.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panel7.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.panel7.Controls.Add(this.label28);
            this.panel7.Controls.Add(this.dataGridView3);
            this.panel7.Controls.Add(this.button25);
            this.panel7.Controls.Add(this.button26);
            this.panel7.Controls.Add(this.button27);
            this.panel7.Controls.Add(this.button28);
            this.panel7.Controls.Add(this.button29);
            this.panel7.Controls.Add(this.textBox19);
            this.panel7.Controls.Add(this.label34);
            this.panel7.Controls.Add(this.label35);
            this.panel7.Controls.Add(this.textBox23);
            this.panel7.Controls.Add(this.textBox24);
            this.panel7.Controls.Add(this.label36);
            this.panel7.Location = new System.Drawing.Point(0, 60);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(577, 441);
            this.panel7.TabIndex = 11;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.Location = new System.Drawing.Point(374, 79);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(80, 20);
            this.label28.TabIndex = 33;
            this.label28.Text = "Table View";
            // 
            // dataGridView3
            // 
            this.dataGridView3.BackgroundColor = System.Drawing.SystemColors.Control;
            this.dataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView3.Location = new System.Drawing.Point(261, 133);
            this.dataGridView3.Name = "dataGridView3";
            this.dataGridView3.Size = new System.Drawing.Size(310, 179);
            this.dataGridView3.TabIndex = 32;
            // 
            // button25
            // 
            this.button25.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button25.BackColor = System.Drawing.SystemColors.ControlText;
            this.button25.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button25.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button25.Location = new System.Drawing.Point(132, 397);
            this.button25.Name = "button25";
            this.button25.Size = new System.Drawing.Size(75, 23);
            this.button25.TabIndex = 26;
            this.button25.Text = "Update";
            this.button25.UseVisualStyleBackColor = false;
            // 
            // button26
            // 
            this.button26.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button26.BackColor = System.Drawing.SystemColors.ControlText;
            this.button26.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button26.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button26.Location = new System.Drawing.Point(238, 397);
            this.button26.Name = "button26";
            this.button26.Size = new System.Drawing.Size(75, 23);
            this.button26.TabIndex = 25;
            this.button26.Text = "Delete";
            this.button26.UseVisualStyleBackColor = false;
            // 
            // button27
            // 
            this.button27.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button27.BackColor = System.Drawing.SystemColors.ControlText;
            this.button27.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button27.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button27.Location = new System.Drawing.Point(335, 397);
            this.button27.Name = "button27";
            this.button27.Size = new System.Drawing.Size(75, 23);
            this.button27.TabIndex = 24;
            this.button27.Text = "Search";
            this.button27.UseVisualStyleBackColor = false;
            // 
            // button28
            // 
            this.button28.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button28.BackColor = System.Drawing.SystemColors.ControlText;
            this.button28.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button28.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button28.Location = new System.Drawing.Point(438, 397);
            this.button28.Name = "button28";
            this.button28.Size = new System.Drawing.Size(75, 23);
            this.button28.TabIndex = 23;
            this.button28.Text = "Show";
            this.button28.UseVisualStyleBackColor = false;
            // 
            // button29
            // 
            this.button29.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button29.BackColor = System.Drawing.SystemColors.ControlText;
            this.button29.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button29.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button29.Location = new System.Drawing.Point(21, 397);
            this.button29.Name = "button29";
            this.button29.Size = new System.Drawing.Size(75, 23);
            this.button29.TabIndex = 21;
            this.button29.Text = "Insert";
            this.button29.UseVisualStyleBackColor = false;
            // 
            // textBox19
            // 
            this.textBox19.Location = new System.Drawing.Point(117, 123);
            this.textBox19.Name = "textBox19";
            this.textBox19.Size = new System.Drawing.Size(104, 20);
            this.textBox19.TabIndex = 20;
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label34.Location = new System.Drawing.Point(17, 254);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(59, 20);
            this.label34.TabIndex = 10;
            this.label34.Text = "Class Id";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label35.Location = new System.Drawing.Point(15, 186);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(87, 20);
            this.label35.TabIndex = 9;
            this.label35.Text = "Course Title";
            // 
            // textBox23
            // 
            this.textBox23.Location = new System.Drawing.Point(117, 254);
            this.textBox23.Name = "textBox23";
            this.textBox23.Size = new System.Drawing.Size(104, 20);
            this.textBox23.TabIndex = 3;
            // 
            // textBox24
            // 
            this.textBox24.Location = new System.Drawing.Point(117, 188);
            this.textBox24.Name = "textBox24";
            this.textBox24.Size = new System.Drawing.Size(104, 20);
            this.textBox24.TabIndex = 1;
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label36.Location = new System.Drawing.Point(17, 123);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(71, 20);
            this.label36.TabIndex = 0;
            this.label36.Text = "Course Id";
            // 
            // label27
            // 
            this.label27.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label27.AutoSize = true;
            this.label27.BackColor = System.Drawing.Color.Transparent;
            this.label27.Font = new System.Drawing.Font("Poppins Black", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label27.Location = new System.Drawing.Point(161, 9);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(214, 48);
            this.label27.TabIndex = 10;
            this.label27.Text = "Course Portal";
            this.label27.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // ExamPortal
            // 
            this.ExamPortal.Controls.Add(this.label40);
            this.ExamPortal.Controls.Add(this.panel8);
            this.ExamPortal.Location = new System.Drawing.Point(4, 22);
            this.ExamPortal.Name = "ExamPortal";
            this.ExamPortal.Padding = new System.Windows.Forms.Padding(3);
            this.ExamPortal.Size = new System.Drawing.Size(577, 497);
            this.ExamPortal.TabIndex = 5;
            this.ExamPortal.Text = "tabPage1";
            this.ExamPortal.UseVisualStyleBackColor = true;
            // 
            // label40
            // 
            this.label40.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label40.AutoSize = true;
            this.label40.BackColor = System.Drawing.Color.Transparent;
            this.label40.Font = new System.Drawing.Font("Poppins Black", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label40.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label40.Location = new System.Drawing.Point(161, 6);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(192, 48);
            this.label40.TabIndex = 13;
            this.label40.Text = "Exam Portal";
            this.label40.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // panel8
            // 
            this.panel8.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panel8.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.panel8.Controls.Add(this.textBox2);
            this.panel8.Controls.Add(this.label6);
            this.panel8.Controls.Add(this.label29);
            this.panel8.Controls.Add(this.dataGridView4);
            this.panel8.Controls.Add(this.button16);
            this.panel8.Controls.Add(this.button17);
            this.panel8.Controls.Add(this.button31);
            this.panel8.Controls.Add(this.button32);
            this.panel8.Controls.Add(this.button33);
            this.panel8.Controls.Add(this.textBox18);
            this.panel8.Controls.Add(this.textBox20);
            this.panel8.Controls.Add(this.label30);
            this.panel8.Controls.Add(this.label31);
            this.panel8.Controls.Add(this.label37);
            this.panel8.Controls.Add(this.label38);
            this.panel8.Controls.Add(this.textBox25);
            this.panel8.Controls.Add(this.textBox26);
            this.panel8.Controls.Add(this.textBox27);
            this.panel8.Controls.Add(this.label39);
            this.panel8.Location = new System.Drawing.Point(0, 57);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(577, 441);
            this.panel8.TabIndex = 12;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(117, 133);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(104, 20);
            this.textBox2.TabIndex = 35;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(17, 133);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(78, 20);
            this.label6.TabIndex = 34;
            this.label6.Text = "Exam Title";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.Location = new System.Drawing.Point(374, 79);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(80, 20);
            this.label29.TabIndex = 33;
            this.label29.Text = "Table View";
            // 
            // dataGridView4
            // 
            this.dataGridView4.BackgroundColor = System.Drawing.SystemColors.Control;
            this.dataGridView4.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView4.Location = new System.Drawing.Point(261, 133);
            this.dataGridView4.Name = "dataGridView4";
            this.dataGridView4.Size = new System.Drawing.Size(310, 179);
            this.dataGridView4.TabIndex = 32;
            // 
            // button16
            // 
            this.button16.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button16.BackColor = System.Drawing.SystemColors.ControlText;
            this.button16.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button16.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button16.Location = new System.Drawing.Point(132, 397);
            this.button16.Name = "button16";
            this.button16.Size = new System.Drawing.Size(75, 23);
            this.button16.TabIndex = 26;
            this.button16.Text = "Update";
            this.button16.UseVisualStyleBackColor = false;
            // 
            // button17
            // 
            this.button17.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button17.BackColor = System.Drawing.SystemColors.ControlText;
            this.button17.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button17.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button17.Location = new System.Drawing.Point(238, 397);
            this.button17.Name = "button17";
            this.button17.Size = new System.Drawing.Size(75, 23);
            this.button17.TabIndex = 25;
            this.button17.Text = "Delete";
            this.button17.UseVisualStyleBackColor = false;
            // 
            // button31
            // 
            this.button31.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button31.BackColor = System.Drawing.SystemColors.ControlText;
            this.button31.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button31.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button31.Location = new System.Drawing.Point(335, 397);
            this.button31.Name = "button31";
            this.button31.Size = new System.Drawing.Size(75, 23);
            this.button31.TabIndex = 24;
            this.button31.Text = "Search";
            this.button31.UseVisualStyleBackColor = false;
            // 
            // button32
            // 
            this.button32.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button32.BackColor = System.Drawing.SystemColors.ControlText;
            this.button32.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button32.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button32.Location = new System.Drawing.Point(438, 397);
            this.button32.Name = "button32";
            this.button32.Size = new System.Drawing.Size(75, 23);
            this.button32.TabIndex = 23;
            this.button32.Text = "Show";
            this.button32.UseVisualStyleBackColor = false;
            // 
            // button33
            // 
            this.button33.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button33.BackColor = System.Drawing.SystemColors.ControlText;
            this.button33.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button33.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button33.Location = new System.Drawing.Point(21, 397);
            this.button33.Name = "button33";
            this.button33.Size = new System.Drawing.Size(75, 23);
            this.button33.TabIndex = 21;
            this.button33.Text = "Insert";
            this.button33.UseVisualStyleBackColor = false;
            // 
            // textBox18
            // 
            this.textBox18.Location = new System.Drawing.Point(117, 81);
            this.textBox18.Name = "textBox18";
            this.textBox18.Size = new System.Drawing.Size(104, 20);
            this.textBox18.TabIndex = 20;
            // 
            // textBox20
            // 
            this.textBox20.Location = new System.Drawing.Point(117, 288);
            this.textBox20.Name = "textBox20";
            this.textBox20.Size = new System.Drawing.Size(104, 20);
            this.textBox20.TabIndex = 16;
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label30.Location = new System.Drawing.Point(3, 286);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(118, 20);
            this.label30.TabIndex = 12;
            this.label30.Text = "Total Weightage";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label31.Location = new System.Drawing.Point(17, 233);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(85, 20);
            this.label31.TabIndex = 11;
            this.label31.Text = "Total Marks";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label37.Location = new System.Drawing.Point(15, 180);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(81, 20);
            this.label37.TabIndex = 10;
            this.label37.Text = "Created By";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label38.Location = new System.Drawing.Point(17, 338);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(71, 20);
            this.label38.TabIndex = 9;
            this.label38.Text = "Course Id";
            // 
            // textBox25
            // 
            this.textBox25.Location = new System.Drawing.Point(117, 235);
            this.textBox25.Name = "textBox25";
            this.textBox25.Size = new System.Drawing.Size(104, 20);
            this.textBox25.TabIndex = 5;
            // 
            // textBox26
            // 
            this.textBox26.Location = new System.Drawing.Point(117, 182);
            this.textBox26.Name = "textBox26";
            this.textBox26.Size = new System.Drawing.Size(104, 20);
            this.textBox26.TabIndex = 3;
            // 
            // textBox27
            // 
            this.textBox27.Location = new System.Drawing.Point(117, 340);
            this.textBox27.Name = "textBox27";
            this.textBox27.Size = new System.Drawing.Size(104, 20);
            this.textBox27.TabIndex = 1;
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label39.Location = new System.Drawing.Point(17, 79);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(62, 20);
            this.label39.TabIndex = 0;
            this.label39.Text = "Exam Id";
            // 
            // TeacherSalary
            // 
            this.TeacherSalary.Controls.Add(this.label42);
            this.TeacherSalary.Controls.Add(this.panel9);
            this.TeacherSalary.Location = new System.Drawing.Point(4, 22);
            this.TeacherSalary.Name = "TeacherSalary";
            this.TeacherSalary.Padding = new System.Windows.Forms.Padding(3);
            this.TeacherSalary.Size = new System.Drawing.Size(577, 497);
            this.TeacherSalary.TabIndex = 6;
            this.TeacherSalary.Text = "tabPage1";
            this.TeacherSalary.UseVisualStyleBackColor = true;
            // 
            // label42
            // 
            this.label42.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label42.AutoSize = true;
            this.label42.BackColor = System.Drawing.Color.Transparent;
            this.label42.Font = new System.Drawing.Font("Poppins Black", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label42.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label42.Location = new System.Drawing.Point(165, 3);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(235, 48);
            this.label42.TabIndex = 12;
            this.label42.Text = "Teacher Salary";
            this.label42.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // panel9
            // 
            this.panel9.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panel9.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.panel9.Controls.Add(this.textBox4);
            this.panel9.Controls.Add(this.label33);
            this.panel9.Controls.Add(this.textBox3);
            this.panel9.Controls.Add(this.label32);
            this.panel9.Controls.Add(this.button45);
            this.panel9.Controls.Add(this.label41);
            this.panel9.Controls.Add(this.dataGridView5);
            this.panel9.Controls.Add(this.dateTimePicker3);
            this.panel9.Controls.Add(this.button36);
            this.panel9.Controls.Add(this.button37);
            this.panel9.Controls.Add(this.button38);
            this.panel9.Controls.Add(this.button39);
            this.panel9.Controls.Add(this.button40);
            this.panel9.Controls.Add(this.textBox29);
            this.panel9.Controls.Add(this.label45);
            this.panel9.Controls.Add(this.label46);
            this.panel9.Controls.Add(this.textBox33);
            this.panel9.Controls.Add(this.label49);
            this.panel9.Location = new System.Drawing.Point(0, 56);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(577, 441);
            this.panel9.TabIndex = 11;
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(135, 289);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(104, 20);
            this.textBox4.TabIndex = 40;
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label33.Location = new System.Drawing.Point(12, 287);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(81, 20);
            this.label33.TabIndex = 39;
            this.label33.Text = "Paid Status";
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(135, 62);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(104, 20);
            this.textBox3.TabIndex = 38;
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label32.Location = new System.Drawing.Point(8, 60);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(121, 20);
            this.label32.TabIndex = 37;
            this.label32.Text = "Teacher Salary Id";
            // 
            // button45
            // 
            this.button45.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button45.BackColor = System.Drawing.SystemColors.ControlText;
            this.button45.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button45.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button45.Location = new System.Drawing.Point(438, 349);
            this.button45.Name = "button45";
            this.button45.Size = new System.Drawing.Size(75, 23);
            this.button45.TabIndex = 36;
            this.button45.Text = "Back";
            this.button45.UseVisualStyleBackColor = false;
            this.button45.Click += new System.EventHandler(this.button45_Click);
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label41.Location = new System.Drawing.Point(374, 69);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(80, 20);
            this.label41.TabIndex = 33;
            this.label41.Text = "Table View";
            // 
            // dataGridView5
            // 
            this.dataGridView5.BackgroundColor = System.Drawing.SystemColors.Control;
            this.dataGridView5.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView5.Location = new System.Drawing.Point(257, 125);
            this.dataGridView5.Name = "dataGridView5";
            this.dataGridView5.Size = new System.Drawing.Size(310, 179);
            this.dataGridView5.TabIndex = 32;
            // 
            // dateTimePicker3
            // 
            this.dateTimePicker3.Location = new System.Drawing.Point(135, 231);
            this.dateTimePicker3.Name = "dateTimePicker3";
            this.dateTimePicker3.Size = new System.Drawing.Size(104, 20);
            this.dateTimePicker3.TabIndex = 31;
            // 
            // button36
            // 
            this.button36.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button36.BackColor = System.Drawing.SystemColors.ControlText;
            this.button36.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button36.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button36.Location = new System.Drawing.Point(132, 397);
            this.button36.Name = "button36";
            this.button36.Size = new System.Drawing.Size(75, 23);
            this.button36.TabIndex = 26;
            this.button36.Text = "Update";
            this.button36.UseVisualStyleBackColor = false;
            // 
            // button37
            // 
            this.button37.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button37.BackColor = System.Drawing.SystemColors.ControlText;
            this.button37.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button37.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button37.Location = new System.Drawing.Point(238, 397);
            this.button37.Name = "button37";
            this.button37.Size = new System.Drawing.Size(75, 23);
            this.button37.TabIndex = 25;
            this.button37.Text = "Delete";
            this.button37.UseVisualStyleBackColor = false;
            // 
            // button38
            // 
            this.button38.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button38.BackColor = System.Drawing.SystemColors.ControlText;
            this.button38.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button38.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button38.Location = new System.Drawing.Point(335, 397);
            this.button38.Name = "button38";
            this.button38.Size = new System.Drawing.Size(75, 23);
            this.button38.TabIndex = 24;
            this.button38.Text = "Search";
            this.button38.UseVisualStyleBackColor = false;
            // 
            // button39
            // 
            this.button39.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button39.BackColor = System.Drawing.SystemColors.ControlText;
            this.button39.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button39.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button39.Location = new System.Drawing.Point(438, 397);
            this.button39.Name = "button39";
            this.button39.Size = new System.Drawing.Size(75, 23);
            this.button39.TabIndex = 23;
            this.button39.Text = "Show";
            this.button39.UseVisualStyleBackColor = false;
            // 
            // button40
            // 
            this.button40.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button40.BackColor = System.Drawing.SystemColors.ControlText;
            this.button40.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button40.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button40.Location = new System.Drawing.Point(21, 397);
            this.button40.Name = "button40";
            this.button40.Size = new System.Drawing.Size(75, 23);
            this.button40.TabIndex = 21;
            this.button40.Text = "Insert";
            this.button40.UseVisualStyleBackColor = false;
            // 
            // textBox29
            // 
            this.textBox29.Location = new System.Drawing.Point(135, 117);
            this.textBox29.Name = "textBox29";
            this.textBox29.Size = new System.Drawing.Size(104, 20);
            this.textBox29.TabIndex = 20;
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label45.Location = new System.Drawing.Point(12, 164);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(106, 20);
            this.label45.TabIndex = 12;
            this.label45.Text = "Designation Id";
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label46.Location = new System.Drawing.Point(12, 231);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(73, 20);
            this.label46.TabIndex = 11;
            this.label46.Text = "Paid Date";
            // 
            // textBox33
            // 
            this.textBox33.Location = new System.Drawing.Point(135, 166);
            this.textBox33.Name = "textBox33";
            this.textBox33.Size = new System.Drawing.Size(104, 20);
            this.textBox33.TabIndex = 3;
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label49.Location = new System.Drawing.Point(12, 115);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(30, 20);
            this.label49.TabIndex = 0;
            this.label49.Text = "TId";
            // 
            // TeacherAttendance
            // 
            this.TeacherAttendance.Controls.Add(this.panel10);
            this.TeacherAttendance.Controls.Add(this.label43);
            this.TeacherAttendance.Location = new System.Drawing.Point(4, 22);
            this.TeacherAttendance.Name = "TeacherAttendance";
            this.TeacherAttendance.Padding = new System.Windows.Forms.Padding(3);
            this.TeacherAttendance.Size = new System.Drawing.Size(577, 497);
            this.TeacherAttendance.TabIndex = 7;
            this.TeacherAttendance.Text = "tabPage1";
            this.TeacherAttendance.UseVisualStyleBackColor = true;
            this.TeacherAttendance.Click += new System.EventHandler(this.TeacherAttendance_Click);
            // 
            // panel10
            // 
            this.panel10.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panel10.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.panel10.Controls.Add(this.textBox31);
            this.panel10.Controls.Add(this.label87);
            this.panel10.Controls.Add(this.textBox22);
            this.panel10.Controls.Add(this.label86);
            this.panel10.Controls.Add(this.button44);
            this.panel10.Controls.Add(this.label50);
            this.panel10.Controls.Add(this.label44);
            this.panel10.Controls.Add(this.dataGridView6);
            this.panel10.Controls.Add(this.dateTimePicker4);
            this.panel10.Controls.Add(this.button34);
            this.panel10.Controls.Add(this.button35);
            this.panel10.Controls.Add(this.button41);
            this.panel10.Controls.Add(this.button42);
            this.panel10.Controls.Add(this.button43);
            this.panel10.Controls.Add(this.textBox28);
            this.panel10.Controls.Add(this.textBox30);
            this.panel10.Controls.Add(this.label51);
            this.panel10.Controls.Add(this.label54);
            this.panel10.Location = new System.Drawing.Point(0, 56);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(577, 441);
            this.panel10.TabIndex = 14;
            this.panel10.Paint += new System.Windows.Forms.PaintEventHandler(this.panel10_Paint);
            // 
            // textBox31
            // 
            this.textBox31.Location = new System.Drawing.Point(151, 252);
            this.textBox31.Name = "textBox31";
            this.textBox31.Size = new System.Drawing.Size(107, 20);
            this.textBox31.TabIndex = 39;
            // 
            // label87
            // 
            this.label87.AutoSize = true;
            this.label87.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label87.Location = new System.Drawing.Point(3, 252);
            this.label87.Name = "label87";
            this.label87.Size = new System.Drawing.Size(129, 20);
            this.label87.TabIndex = 38;
            this.label87.Text = "Attendance Status";
            // 
            // textBox22
            // 
            this.textBox22.Location = new System.Drawing.Point(151, 209);
            this.textBox22.Name = "textBox22";
            this.textBox22.Size = new System.Drawing.Size(107, 20);
            this.textBox22.TabIndex = 37;
            // 
            // label86
            // 
            this.label86.AutoSize = true;
            this.label86.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label86.Location = new System.Drawing.Point(3, 154);
            this.label86.Name = "label86";
            this.label86.Size = new System.Drawing.Size(77, 20);
            this.label86.TabIndex = 36;
            this.label86.Text = "Teacher Id";
            // 
            // button44
            // 
            this.button44.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button44.BackColor = System.Drawing.SystemColors.ControlText;
            this.button44.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button44.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button44.Location = new System.Drawing.Point(438, 348);
            this.button44.Name = "button44";
            this.button44.Size = new System.Drawing.Size(75, 23);
            this.button44.TabIndex = 35;
            this.button44.Text = "Back";
            this.button44.UseVisualStyleBackColor = false;
            this.button44.Click += new System.EventHandler(this.button44_Click);
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label50.Location = new System.Drawing.Point(3, 209);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(70, 20);
            this.label50.TabIndex = 34;
            this.label50.Text = "Admin Id";
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label44.Location = new System.Drawing.Point(379, 69);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(80, 20);
            this.label44.TabIndex = 33;
            this.label44.Text = "Table View";
            // 
            // dataGridView6
            // 
            this.dataGridView6.BackgroundColor = System.Drawing.SystemColors.Control;
            this.dataGridView6.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView6.Location = new System.Drawing.Point(264, 103);
            this.dataGridView6.Name = "dataGridView6";
            this.dataGridView6.Size = new System.Drawing.Size(310, 179);
            this.dataGridView6.TabIndex = 32;
            // 
            // dateTimePicker4
            // 
            this.dateTimePicker4.Location = new System.Drawing.Point(151, 296);
            this.dateTimePicker4.Name = "dateTimePicker4";
            this.dateTimePicker4.Size = new System.Drawing.Size(107, 20);
            this.dateTimePicker4.TabIndex = 31;
            // 
            // button34
            // 
            this.button34.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button34.BackColor = System.Drawing.SystemColors.ControlText;
            this.button34.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button34.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button34.Location = new System.Drawing.Point(132, 397);
            this.button34.Name = "button34";
            this.button34.Size = new System.Drawing.Size(75, 23);
            this.button34.TabIndex = 26;
            this.button34.Text = "Update";
            this.button34.UseVisualStyleBackColor = false;
            // 
            // button35
            // 
            this.button35.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button35.BackColor = System.Drawing.SystemColors.ControlText;
            this.button35.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button35.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button35.Location = new System.Drawing.Point(238, 397);
            this.button35.Name = "button35";
            this.button35.Size = new System.Drawing.Size(75, 23);
            this.button35.TabIndex = 25;
            this.button35.Text = "Delete";
            this.button35.UseVisualStyleBackColor = false;
            // 
            // button41
            // 
            this.button41.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button41.BackColor = System.Drawing.SystemColors.ControlText;
            this.button41.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button41.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button41.Location = new System.Drawing.Point(335, 397);
            this.button41.Name = "button41";
            this.button41.Size = new System.Drawing.Size(75, 23);
            this.button41.TabIndex = 24;
            this.button41.Text = "Search";
            this.button41.UseVisualStyleBackColor = false;
            // 
            // button42
            // 
            this.button42.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button42.BackColor = System.Drawing.SystemColors.ControlText;
            this.button42.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button42.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button42.Location = new System.Drawing.Point(438, 397);
            this.button42.Name = "button42";
            this.button42.Size = new System.Drawing.Size(75, 23);
            this.button42.TabIndex = 23;
            this.button42.Text = "Show";
            this.button42.UseVisualStyleBackColor = false;
            // 
            // button43
            // 
            this.button43.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button43.BackColor = System.Drawing.SystemColors.ControlText;
            this.button43.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button43.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button43.Location = new System.Drawing.Point(21, 397);
            this.button43.Name = "button43";
            this.button43.Size = new System.Drawing.Size(75, 23);
            this.button43.TabIndex = 21;
            this.button43.Text = "Insert";
            this.button43.UseVisualStyleBackColor = false;
            // 
            // textBox28
            // 
            this.textBox28.Location = new System.Drawing.Point(151, 90);
            this.textBox28.Name = "textBox28";
            this.textBox28.Size = new System.Drawing.Size(107, 20);
            this.textBox28.TabIndex = 20;
            // 
            // textBox30
            // 
            this.textBox30.Location = new System.Drawing.Point(151, 154);
            this.textBox30.Name = "textBox30";
            this.textBox30.Size = new System.Drawing.Size(107, 20);
            this.textBox30.TabIndex = 16;
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label51.Location = new System.Drawing.Point(3, 300);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(121, 20);
            this.label51.TabIndex = 11;
            this.label51.Text = "Attendance Date";
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label54.Location = new System.Drawing.Point(8, 89);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(140, 40);
            this.label54.TabIndex = 0;
            this.label54.Text = "Teacher Attendance\r\nId\r\n";
            this.label54.Click += new System.EventHandler(this.label54_Click);
            // 
            // label43
            // 
            this.label43.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label43.AutoSize = true;
            this.label43.BackColor = System.Drawing.Color.Transparent;
            this.label43.Font = new System.Drawing.Font("Poppins Black", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label43.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label43.Location = new System.Drawing.Point(124, 5);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(311, 48);
            this.label43.TabIndex = 13;
            this.label43.Text = "Teacher Attendance";
            this.label43.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // StudentFee
            // 
            this.StudentFee.Controls.Add(this.label62);
            this.StudentFee.Controls.Add(this.panel11);
            this.StudentFee.Location = new System.Drawing.Point(4, 22);
            this.StudentFee.Name = "StudentFee";
            this.StudentFee.Padding = new System.Windows.Forms.Padding(3);
            this.StudentFee.Size = new System.Drawing.Size(577, 497);
            this.StudentFee.TabIndex = 8;
            this.StudentFee.Text = "tabPage1";
            this.StudentFee.UseVisualStyleBackColor = true;
            // 
            // label62
            // 
            this.label62.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label62.AutoSize = true;
            this.label62.BackColor = System.Drawing.Color.Transparent;
            this.label62.Font = new System.Drawing.Font("Poppins Black", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label62.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label62.Location = new System.Drawing.Point(173, 5);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(189, 48);
            this.label62.TabIndex = 9;
            this.label62.Text = "Student Fee";
            this.label62.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // panel11
            // 
            this.panel11.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panel11.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.panel11.Controls.Add(this.comboBox4);
            this.panel11.Controls.Add(this.comboBox3);
            this.panel11.Controls.Add(this.button62);
            this.panel11.Controls.Add(this.dateTimePicker6);
            this.panel11.Controls.Add(this.label52);
            this.panel11.Controls.Add(this.dataGridView7);
            this.panel11.Controls.Add(this.dateTimePicker5);
            this.panel11.Controls.Add(this.button50);
            this.panel11.Controls.Add(this.button51);
            this.panel11.Controls.Add(this.button52);
            this.panel11.Controls.Add(this.button53);
            this.panel11.Controls.Add(this.button54);
            this.panel11.Controls.Add(this.label53);
            this.panel11.Controls.Add(this.label58);
            this.panel11.Controls.Add(this.label59);
            this.panel11.Controls.Add(this.label60);
            this.panel11.Controls.Add(this.textBox40);
            this.panel11.Controls.Add(this.label61);
            this.panel11.Location = new System.Drawing.Point(0, 57);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(577, 441);
            this.panel11.TabIndex = 8;
            // 
            // comboBox4
            // 
            this.comboBox4.FormattingEnabled = true;
            this.comboBox4.Location = new System.Drawing.Point(129, 299);
            this.comboBox4.Name = "comboBox4";
            this.comboBox4.Size = new System.Drawing.Size(126, 21);
            this.comboBox4.TabIndex = 38;
            // 
            // comboBox3
            // 
            this.comboBox3.FormattingEnabled = true;
            this.comboBox3.Location = new System.Drawing.Point(129, 63);
            this.comboBox3.Name = "comboBox3";
            this.comboBox3.Size = new System.Drawing.Size(126, 21);
            this.comboBox3.TabIndex = 37;
            // 
            // button62
            // 
            this.button62.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button62.BackColor = System.Drawing.SystemColors.ControlText;
            this.button62.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button62.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button62.Location = new System.Drawing.Point(438, 350);
            this.button62.Name = "button62";
            this.button62.Size = new System.Drawing.Size(75, 23);
            this.button62.TabIndex = 36;
            this.button62.Text = "Back";
            this.button62.UseVisualStyleBackColor = false;
            this.button62.Click += new System.EventHandler(this.button62_Click);
            // 
            // dateTimePicker6
            // 
            this.dateTimePicker6.Location = new System.Drawing.Point(129, 182);
            this.dateTimePicker6.Name = "dateTimePicker6";
            this.dateTimePicker6.Size = new System.Drawing.Size(126, 20);
            this.dateTimePicker6.TabIndex = 34;
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label52.Location = new System.Drawing.Point(377, 78);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(80, 20);
            this.label52.TabIndex = 33;
            this.label52.Text = "Table View";
            // 
            // dataGridView7
            // 
            this.dataGridView7.BackgroundColor = System.Drawing.SystemColors.Control;
            this.dataGridView7.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView7.Location = new System.Drawing.Point(264, 117);
            this.dataGridView7.Name = "dataGridView7";
            this.dataGridView7.Size = new System.Drawing.Size(310, 179);
            this.dataGridView7.TabIndex = 32;
            // 
            // dateTimePicker5
            // 
            this.dateTimePicker5.Location = new System.Drawing.Point(129, 244);
            this.dateTimePicker5.Name = "dateTimePicker5";
            this.dateTimePicker5.Size = new System.Drawing.Size(126, 20);
            this.dateTimePicker5.TabIndex = 31;
            // 
            // button50
            // 
            this.button50.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button50.BackColor = System.Drawing.SystemColors.ControlText;
            this.button50.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button50.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button50.Location = new System.Drawing.Point(132, 397);
            this.button50.Name = "button50";
            this.button50.Size = new System.Drawing.Size(75, 23);
            this.button50.TabIndex = 26;
            this.button50.Text = "Update";
            this.button50.UseVisualStyleBackColor = false;
            // 
            // button51
            // 
            this.button51.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button51.BackColor = System.Drawing.SystemColors.ControlText;
            this.button51.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button51.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button51.Location = new System.Drawing.Point(238, 397);
            this.button51.Name = "button51";
            this.button51.Size = new System.Drawing.Size(75, 23);
            this.button51.TabIndex = 25;
            this.button51.Text = "Delete";
            this.button51.UseVisualStyleBackColor = false;
            // 
            // button52
            // 
            this.button52.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button52.BackColor = System.Drawing.SystemColors.ControlText;
            this.button52.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button52.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button52.Location = new System.Drawing.Point(335, 397);
            this.button52.Name = "button52";
            this.button52.Size = new System.Drawing.Size(75, 23);
            this.button52.TabIndex = 24;
            this.button52.Text = "Search";
            this.button52.UseVisualStyleBackColor = false;
            // 
            // button53
            // 
            this.button53.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button53.BackColor = System.Drawing.SystemColors.ControlText;
            this.button53.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button53.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button53.Location = new System.Drawing.Point(438, 397);
            this.button53.Name = "button53";
            this.button53.Size = new System.Drawing.Size(75, 23);
            this.button53.TabIndex = 23;
            this.button53.Text = "Show";
            this.button53.UseVisualStyleBackColor = false;
            // 
            // button54
            // 
            this.button54.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button54.BackColor = System.Drawing.SystemColors.ControlText;
            this.button54.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button54.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button54.Location = new System.Drawing.Point(21, 397);
            this.button54.Name = "button54";
            this.button54.Size = new System.Drawing.Size(75, 23);
            this.button54.TabIndex = 21;
            this.button54.Text = "Insert";
            this.button54.UseVisualStyleBackColor = false;
            this.button54.Click += new System.EventHandler(this.button54_Click);
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label53.Location = new System.Drawing.Point(3, 182);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(120, 20);
            this.label53.TabIndex = 15;
            this.label53.Text = "Submission Date";
            // 
            // label58
            // 
            this.label58.AutoSize = true;
            this.label58.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label58.Location = new System.Drawing.Point(6, 224);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(84, 40);
            this.label58.TabIndex = 11;
            this.label58.Text = "Submission\r\nDeadline";
            this.label58.Click += new System.EventHandler(this.label58_Click);
            // 
            // label59
            // 
            this.label59.AutoSize = true;
            this.label59.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label59.Location = new System.Drawing.Point(9, 300);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(76, 20);
            this.label59.TabIndex = 10;
            this.label59.Text = "Fee Status";
            // 
            // label60
            // 
            this.label60.AutoSize = true;
            this.label60.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label60.Location = new System.Drawing.Point(9, 124);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(85, 20);
            this.label60.TabIndex = 9;
            this.label60.Text = "Std Reg No";
            // 
            // textBox40
            // 
            this.textBox40.Location = new System.Drawing.Point(129, 124);
            this.textBox40.Name = "textBox40";
            this.textBox40.Size = new System.Drawing.Size(126, 20);
            this.textBox40.TabIndex = 1;
            // 
            // label61
            // 
            this.label61.AutoSize = true;
            this.label61.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label61.Location = new System.Drawing.Point(9, 61);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(75, 20);
            this.label61.TabIndex = 0;
            this.label61.Text = "Std Fee Id";
            // 
            // StudentResult
            // 
            this.StudentResult.Controls.Add(this.panel12);
            this.StudentResult.Controls.Add(this.label55);
            this.StudentResult.Location = new System.Drawing.Point(4, 22);
            this.StudentResult.Name = "StudentResult";
            this.StudentResult.Padding = new System.Windows.Forms.Padding(3);
            this.StudentResult.Size = new System.Drawing.Size(577, 497);
            this.StudentResult.TabIndex = 9;
            this.StudentResult.Text = "tabPage1";
            this.StudentResult.UseVisualStyleBackColor = true;
            // 
            // panel12
            // 
            this.panel12.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panel12.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.panel12.Controls.Add(this.textBox21);
            this.panel12.Controls.Add(this.label82);
            this.panel12.Controls.Add(this.button63);
            this.panel12.Controls.Add(this.label56);
            this.panel12.Controls.Add(this.dataGridView8);
            this.panel12.Controls.Add(this.button55);
            this.panel12.Controls.Add(this.button56);
            this.panel12.Controls.Add(this.button57);
            this.panel12.Controls.Add(this.button58);
            this.panel12.Controls.Add(this.button59);
            this.panel12.Controls.Add(this.textBox36);
            this.panel12.Controls.Add(this.textBox37);
            this.panel12.Controls.Add(this.textBox39);
            this.panel12.Controls.Add(this.label63);
            this.panel12.Controls.Add(this.label65);
            this.panel12.Controls.Add(this.label66);
            this.panel12.Controls.Add(this.label67);
            this.panel12.Controls.Add(this.label68);
            this.panel12.Controls.Add(this.textBox41);
            this.panel12.Controls.Add(this.textBox42);
            this.panel12.Controls.Add(this.textBox43);
            this.panel12.Controls.Add(this.label69);
            this.panel12.Location = new System.Drawing.Point(0, 56);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(577, 441);
            this.panel12.TabIndex = 11;
            this.panel12.Paint += new System.Windows.Forms.PaintEventHandler(this.panel12_Paint);
            // 
            // textBox21
            // 
            this.textBox21.Location = new System.Drawing.Point(129, 312);
            this.textBox21.Name = "textBox21";
            this.textBox21.Size = new System.Drawing.Size(104, 20);
            this.textBox21.TabIndex = 36;
            // 
            // label82
            // 
            this.label82.AutoSize = true;
            this.label82.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label82.Location = new System.Drawing.Point(16, 90);
            this.label82.Name = "label82";
            this.label82.Size = new System.Drawing.Size(85, 20);
            this.label82.TabIndex = 35;
            this.label82.Text = "Std Reg No";
            // 
            // button63
            // 
            this.button63.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button63.BackColor = System.Drawing.SystemColors.ControlText;
            this.button63.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button63.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button63.Location = new System.Drawing.Point(438, 350);
            this.button63.Name = "button63";
            this.button63.Size = new System.Drawing.Size(75, 23);
            this.button63.TabIndex = 34;
            this.button63.Text = "Back";
            this.button63.UseVisualStyleBackColor = false;
            this.button63.Click += new System.EventHandler(this.button63_Click);
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label56.Location = new System.Drawing.Point(374, 69);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(80, 20);
            this.label56.TabIndex = 33;
            this.label56.Text = "Table View";
            // 
            // dataGridView8
            // 
            this.dataGridView8.BackgroundColor = System.Drawing.SystemColors.Control;
            this.dataGridView8.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView8.Location = new System.Drawing.Point(261, 118);
            this.dataGridView8.Name = "dataGridView8";
            this.dataGridView8.Size = new System.Drawing.Size(310, 179);
            this.dataGridView8.TabIndex = 32;
            // 
            // button55
            // 
            this.button55.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button55.BackColor = System.Drawing.SystemColors.ControlText;
            this.button55.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button55.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button55.Location = new System.Drawing.Point(132, 397);
            this.button55.Name = "button55";
            this.button55.Size = new System.Drawing.Size(75, 23);
            this.button55.TabIndex = 26;
            this.button55.Text = "Update";
            this.button55.UseVisualStyleBackColor = false;
            // 
            // button56
            // 
            this.button56.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button56.BackColor = System.Drawing.SystemColors.ControlText;
            this.button56.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button56.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button56.Location = new System.Drawing.Point(238, 397);
            this.button56.Name = "button56";
            this.button56.Size = new System.Drawing.Size(75, 23);
            this.button56.TabIndex = 25;
            this.button56.Text = "Delete";
            this.button56.UseVisualStyleBackColor = false;
            // 
            // button57
            // 
            this.button57.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button57.BackColor = System.Drawing.SystemColors.ControlText;
            this.button57.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button57.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button57.Location = new System.Drawing.Point(335, 397);
            this.button57.Name = "button57";
            this.button57.Size = new System.Drawing.Size(75, 23);
            this.button57.TabIndex = 24;
            this.button57.Text = "Search";
            this.button57.UseVisualStyleBackColor = false;
            // 
            // button58
            // 
            this.button58.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button58.BackColor = System.Drawing.SystemColors.ControlText;
            this.button58.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button58.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button58.Location = new System.Drawing.Point(438, 397);
            this.button58.Name = "button58";
            this.button58.Size = new System.Drawing.Size(75, 23);
            this.button58.TabIndex = 23;
            this.button58.Text = "Show";
            this.button58.UseVisualStyleBackColor = false;
            // 
            // button59
            // 
            this.button59.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button59.BackColor = System.Drawing.SystemColors.ControlText;
            this.button59.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button59.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button59.Location = new System.Drawing.Point(21, 397);
            this.button59.Name = "button59";
            this.button59.Size = new System.Drawing.Size(75, 23);
            this.button59.TabIndex = 21;
            this.button59.Text = "Insert";
            this.button59.UseVisualStyleBackColor = false;
            // 
            // textBox36
            // 
            this.textBox36.Location = new System.Drawing.Point(129, 49);
            this.textBox36.Name = "textBox36";
            this.textBox36.Size = new System.Drawing.Size(104, 20);
            this.textBox36.TabIndex = 20;
            // 
            // textBox37
            // 
            this.textBox37.Location = new System.Drawing.Point(129, 270);
            this.textBox37.Name = "textBox37";
            this.textBox37.Size = new System.Drawing.Size(104, 20);
            this.textBox37.TabIndex = 17;
            // 
            // textBox39
            // 
            this.textBox39.Location = new System.Drawing.Point(129, 223);
            this.textBox39.Name = "textBox39";
            this.textBox39.Size = new System.Drawing.Size(104, 20);
            this.textBox39.TabIndex = 16;
            // 
            // label63
            // 
            this.label63.AutoSize = true;
            this.label63.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label63.Location = new System.Drawing.Point(17, 223);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(70, 20);
            this.label63.TabIndex = 14;
            this.label63.Text = "Admin Id";
            this.label63.Click += new System.EventHandler(this.label63_Click);
            // 
            // label65
            // 
            this.label65.AutoSize = true;
            this.label65.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label65.Location = new System.Drawing.Point(8, 310);
            this.label65.Name = "label65";
            this.label65.Size = new System.Drawing.Size(81, 40);
            this.label65.TabIndex = 12;
            this.label65.Text = "Obtained\r\nWeightage";
            this.label65.Click += new System.EventHandler(this.label65_Click);
            // 
            // label66
            // 
            this.label66.AutoSize = true;
            this.label66.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label66.Location = new System.Drawing.Point(8, 268);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(114, 20);
            this.label66.TabIndex = 11;
            this.label66.Text = "Obtained Marks";
            // 
            // label67
            // 
            this.label67.AutoSize = true;
            this.label67.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label67.Location = new System.Drawing.Point(17, 178);
            this.label67.Name = "label67";
            this.label67.Size = new System.Drawing.Size(62, 20);
            this.label67.TabIndex = 10;
            this.label67.Text = "Exam Id\r\n";
            this.label67.Click += new System.EventHandler(this.label67_Click);
            // 
            // label68
            // 
            this.label68.AutoSize = true;
            this.label68.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label68.Location = new System.Drawing.Point(16, 131);
            this.label68.Name = "label68";
            this.label68.Size = new System.Drawing.Size(30, 20);
            this.label68.TabIndex = 9;
            this.label68.Text = "Tid";
            // 
            // textBox41
            // 
            this.textBox41.Location = new System.Drawing.Point(129, 180);
            this.textBox41.Name = "textBox41";
            this.textBox41.Size = new System.Drawing.Size(104, 20);
            this.textBox41.TabIndex = 5;
            // 
            // textBox42
            // 
            this.textBox42.Location = new System.Drawing.Point(129, 133);
            this.textBox42.Name = "textBox42";
            this.textBox42.Size = new System.Drawing.Size(104, 20);
            this.textBox42.TabIndex = 3;
            // 
            // textBox43
            // 
            this.textBox43.Location = new System.Drawing.Point(129, 95);
            this.textBox43.Name = "textBox43";
            this.textBox43.Size = new System.Drawing.Size(104, 20);
            this.textBox43.TabIndex = 1;
            // 
            // label69
            // 
            this.label69.AutoSize = true;
            this.label69.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label69.Location = new System.Drawing.Point(17, 47);
            this.label69.Name = "label69";
            this.label69.Size = new System.Drawing.Size(92, 20);
            this.label69.TabIndex = 0;
            this.label69.Text = "Std Result Id";
            // 
            // label55
            // 
            this.label55.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label55.AutoSize = true;
            this.label55.BackColor = System.Drawing.Color.Transparent;
            this.label55.Font = new System.Drawing.Font("Poppins Black", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label55.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label55.Location = new System.Drawing.Point(166, 5);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(230, 48);
            this.label55.TabIndex = 10;
            this.label55.Text = "Student Result";
            this.label55.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // StudentAttendance
            // 
            this.StudentAttendance.Controls.Add(this.panel13);
            this.StudentAttendance.Controls.Add(this.label57);
            this.StudentAttendance.Location = new System.Drawing.Point(4, 22);
            this.StudentAttendance.Name = "StudentAttendance";
            this.StudentAttendance.Padding = new System.Windows.Forms.Padding(3);
            this.StudentAttendance.Size = new System.Drawing.Size(577, 497);
            this.StudentAttendance.TabIndex = 10;
            this.StudentAttendance.Text = "tabPage1";
            this.StudentAttendance.UseVisualStyleBackColor = true;
            // 
            // panel13
            // 
            this.panel13.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panel13.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.panel13.Controls.Add(this.comboBox10);
            this.panel13.Controls.Add(this.comboBox9);
            this.panel13.Controls.Add(this.label4);
            this.panel13.Controls.Add(this.label3);
            this.panel13.Controls.Add(this.comboBox6);
            this.panel13.Controls.Add(this.comboBox5);
            this.panel13.Controls.Add(this.label73);
            this.panel13.Controls.Add(this.button46);
            this.panel13.Controls.Add(this.label64);
            this.panel13.Controls.Add(this.label70);
            this.panel13.Controls.Add(this.dataGridView9);
            this.panel13.Controls.Add(this.dateTimePicker7);
            this.panel13.Controls.Add(this.button47);
            this.panel13.Controls.Add(this.button48);
            this.panel13.Controls.Add(this.button49);
            this.panel13.Controls.Add(this.button60);
            this.panel13.Controls.Add(this.button61);
            this.panel13.Controls.Add(this.label71);
            this.panel13.Location = new System.Drawing.Point(0, 57);
            this.panel13.Name = "panel13";
            this.panel13.Size = new System.Drawing.Size(577, 441);
            this.panel13.TabIndex = 15;
            // 
            // comboBox10
            // 
            this.comboBox10.FormattingEnabled = true;
            this.comboBox10.Location = new System.Drawing.Point(147, 193);
            this.comboBox10.Name = "comboBox10";
            this.comboBox10.Size = new System.Drawing.Size(111, 21);
            this.comboBox10.TabIndex = 42;
            // 
            // comboBox9
            // 
            this.comboBox9.FormattingEnabled = true;
            this.comboBox9.Location = new System.Drawing.Point(147, 145);
            this.comboBox9.Name = "comboBox9";
            this.comboBox9.Size = new System.Drawing.Size(111, 21);
            this.comboBox9.TabIndex = 41;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(8, 143);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(77, 20);
            this.label4.TabIndex = 40;
            this.label4.Text = "Teacher Id";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(6, 92);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(128, 20);
            this.label3.TabIndex = 39;
            this.label3.Text = "Std Attendance Id\r\n";
            // 
            // comboBox6
            // 
            this.comboBox6.FormattingEnabled = true;
            this.comboBox6.Location = new System.Drawing.Point(147, 241);
            this.comboBox6.Name = "comboBox6";
            this.comboBox6.Size = new System.Drawing.Size(113, 21);
            this.comboBox6.TabIndex = 38;
            // 
            // comboBox5
            // 
            this.comboBox5.FormattingEnabled = true;
            this.comboBox5.Location = new System.Drawing.Point(147, 94);
            this.comboBox5.Name = "comboBox5";
            this.comboBox5.Size = new System.Drawing.Size(111, 21);
            this.comboBox5.TabIndex = 37;
            // 
            // label73
            // 
            this.label73.AutoSize = true;
            this.label73.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label73.Location = new System.Drawing.Point(6, 191);
            this.label73.Name = "label73";
            this.label73.Size = new System.Drawing.Size(85, 20);
            this.label73.TabIndex = 36;
            this.label73.Text = "Std Reg No";
            // 
            // button46
            // 
            this.button46.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button46.BackColor = System.Drawing.SystemColors.ControlText;
            this.button46.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button46.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button46.Location = new System.Drawing.Point(438, 348);
            this.button46.Name = "button46";
            this.button46.Size = new System.Drawing.Size(75, 23);
            this.button46.TabIndex = 35;
            this.button46.Text = "Back";
            this.button46.UseVisualStyleBackColor = false;
            this.button46.Click += new System.EventHandler(this.button46_Click);
            // 
            // label64
            // 
            this.label64.AutoSize = true;
            this.label64.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label64.Location = new System.Drawing.Point(6, 239);
            this.label64.Name = "label64";
            this.label64.Size = new System.Drawing.Size(129, 20);
            this.label64.TabIndex = 34;
            this.label64.Text = "Attendance Status";
            // 
            // label70
            // 
            this.label70.AutoSize = true;
            this.label70.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label70.Location = new System.Drawing.Point(380, 60);
            this.label70.Name = "label70";
            this.label70.Size = new System.Drawing.Size(80, 20);
            this.label70.TabIndex = 33;
            this.label70.Text = "Table View";
            // 
            // dataGridView9
            // 
            this.dataGridView9.BackgroundColor = System.Drawing.SystemColors.Control;
            this.dataGridView9.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView9.Location = new System.Drawing.Point(264, 103);
            this.dataGridView9.Name = "dataGridView9";
            this.dataGridView9.Size = new System.Drawing.Size(310, 179);
            this.dataGridView9.TabIndex = 32;
            this.dataGridView9.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView9_CellContentClick);
            // 
            // dateTimePicker7
            // 
            this.dateTimePicker7.Location = new System.Drawing.Point(147, 286);
            this.dateTimePicker7.Name = "dateTimePicker7";
            this.dateTimePicker7.Size = new System.Drawing.Size(113, 20);
            this.dateTimePicker7.TabIndex = 31;
            // 
            // button47
            // 
            this.button47.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button47.BackColor = System.Drawing.SystemColors.ControlText;
            this.button47.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button47.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button47.Location = new System.Drawing.Point(132, 397);
            this.button47.Name = "button47";
            this.button47.Size = new System.Drawing.Size(75, 23);
            this.button47.TabIndex = 26;
            this.button47.Text = "Update";
            this.button47.UseVisualStyleBackColor = false;
            this.button47.Click += new System.EventHandler(this.button47_Click);
            // 
            // button48
            // 
            this.button48.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button48.BackColor = System.Drawing.SystemColors.ControlText;
            this.button48.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button48.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button48.Location = new System.Drawing.Point(238, 397);
            this.button48.Name = "button48";
            this.button48.Size = new System.Drawing.Size(75, 23);
            this.button48.TabIndex = 25;
            this.button48.Text = "Delete";
            this.button48.UseVisualStyleBackColor = false;
            this.button48.Click += new System.EventHandler(this.button48_Click);
            // 
            // button49
            // 
            this.button49.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button49.BackColor = System.Drawing.SystemColors.ControlText;
            this.button49.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button49.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button49.Location = new System.Drawing.Point(335, 397);
            this.button49.Name = "button49";
            this.button49.Size = new System.Drawing.Size(75, 23);
            this.button49.TabIndex = 24;
            this.button49.Text = "Search";
            this.button49.UseVisualStyleBackColor = false;
            this.button49.Click += new System.EventHandler(this.button49_Click);
            // 
            // button60
            // 
            this.button60.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button60.BackColor = System.Drawing.SystemColors.ControlText;
            this.button60.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button60.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button60.Location = new System.Drawing.Point(438, 397);
            this.button60.Name = "button60";
            this.button60.Size = new System.Drawing.Size(75, 23);
            this.button60.TabIndex = 23;
            this.button60.Text = "Show";
            this.button60.UseVisualStyleBackColor = false;
            this.button60.Click += new System.EventHandler(this.button60_Click);
            // 
            // button61
            // 
            this.button61.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button61.BackColor = System.Drawing.SystemColors.ControlText;
            this.button61.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button61.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button61.Location = new System.Drawing.Point(21, 397);
            this.button61.Name = "button61";
            this.button61.Size = new System.Drawing.Size(75, 23);
            this.button61.TabIndex = 21;
            this.button61.Text = "Insert";
            this.button61.UseVisualStyleBackColor = false;
            this.button61.Click += new System.EventHandler(this.button61_Click);
            // 
            // label71
            // 
            this.label71.AutoSize = true;
            this.label71.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label71.Location = new System.Drawing.Point(6, 286);
            this.label71.Name = "label71";
            this.label71.Size = new System.Drawing.Size(121, 20);
            this.label71.TabIndex = 11;
            this.label71.Text = "Attendance Date";
            // 
            // label57
            // 
            this.label57.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label57.AutoSize = true;
            this.label57.BackColor = System.Drawing.Color.Transparent;
            this.label57.Font = new System.Drawing.Font("Poppins Black", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label57.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label57.Location = new System.Drawing.Point(130, 5);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(308, 48);
            this.label57.TabIndex = 9;
            this.label57.Text = "Student Attendance";
            this.label57.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.label57.Click += new System.EventHandler(this.label57_Click);
            // 
            // StudentClass
            // 
            this.StudentClass.Controls.Add(this.panel14);
            this.StudentClass.Controls.Add(this.label74);
            this.StudentClass.Location = new System.Drawing.Point(4, 22);
            this.StudentClass.Name = "StudentClass";
            this.StudentClass.Padding = new System.Windows.Forms.Padding(3);
            this.StudentClass.Size = new System.Drawing.Size(577, 497);
            this.StudentClass.TabIndex = 11;
            this.StudentClass.Text = "tabPage1";
            this.StudentClass.UseVisualStyleBackColor = true;
            // 
            // panel14
            // 
            this.panel14.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panel14.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.panel14.Controls.Add(this.textBox1);
            this.panel14.Controls.Add(this.label5);
            this.panel14.Controls.Add(this.button70);
            this.panel14.Controls.Add(this.button64);
            this.panel14.Controls.Add(this.label75);
            this.panel14.Controls.Add(this.dataGridView10);
            this.panel14.Controls.Add(this.button65);
            this.panel14.Controls.Add(this.button66);
            this.panel14.Controls.Add(this.button67);
            this.panel14.Controls.Add(this.button68);
            this.panel14.Controls.Add(this.button69);
            this.panel14.Controls.Add(this.textBox46);
            this.panel14.Controls.Add(this.textBox47);
            this.panel14.Controls.Add(this.label76);
            this.panel14.Controls.Add(this.label78);
            this.panel14.Controls.Add(this.label79);
            this.panel14.Controls.Add(this.textBox48);
            this.panel14.Controls.Add(this.textBox49);
            this.panel14.Controls.Add(this.label80);
            this.panel14.Location = new System.Drawing.Point(0, 56);
            this.panel14.Name = "panel14";
            this.panel14.Size = new System.Drawing.Size(577, 441);
            this.panel14.TabIndex = 12;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(206, 322);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(107, 20);
            this.textBox1.TabIndex = 39;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(17, 320);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(181, 20);
            this.label5.TabIndex = 38;
            this.label5.Text = "Total Number Of Students";
            // 
            // button70
            // 
            this.button70.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button70.BackColor = System.Drawing.SystemColors.ControlText;
            this.button70.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button70.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button70.Location = new System.Drawing.Point(16, 32);
            this.button70.Name = "button70";
            this.button70.Size = new System.Drawing.Size(75, 23);
            this.button70.TabIndex = 37;
            this.button70.Text = "Section";
            this.button70.UseVisualStyleBackColor = false;
            this.button70.Click += new System.EventHandler(this.button70_Click);
            // 
            // button64
            // 
            this.button64.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button64.BackColor = System.Drawing.SystemColors.ControlText;
            this.button64.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button64.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button64.Location = new System.Drawing.Point(438, 349);
            this.button64.Name = "button64";
            this.button64.Size = new System.Drawing.Size(75, 23);
            this.button64.TabIndex = 36;
            this.button64.Text = "Back";
            this.button64.UseVisualStyleBackColor = false;
            this.button64.Click += new System.EventHandler(this.button64_Click);
            // 
            // label75
            // 
            this.label75.AutoSize = true;
            this.label75.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label75.Location = new System.Drawing.Point(374, 69);
            this.label75.Name = "label75";
            this.label75.Size = new System.Drawing.Size(80, 20);
            this.label75.TabIndex = 33;
            this.label75.Text = "Table View";
            // 
            // dataGridView10
            // 
            this.dataGridView10.BackgroundColor = System.Drawing.SystemColors.Control;
            this.dataGridView10.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView10.Location = new System.Drawing.Point(257, 125);
            this.dataGridView10.Name = "dataGridView10";
            this.dataGridView10.Size = new System.Drawing.Size(310, 179);
            this.dataGridView10.TabIndex = 32;
            // 
            // button65
            // 
            this.button65.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button65.BackColor = System.Drawing.SystemColors.ControlText;
            this.button65.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button65.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button65.Location = new System.Drawing.Point(132, 397);
            this.button65.Name = "button65";
            this.button65.Size = new System.Drawing.Size(75, 23);
            this.button65.TabIndex = 26;
            this.button65.Text = "Update";
            this.button65.UseVisualStyleBackColor = false;
            // 
            // button66
            // 
            this.button66.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button66.BackColor = System.Drawing.SystemColors.ControlText;
            this.button66.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button66.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button66.Location = new System.Drawing.Point(238, 397);
            this.button66.Name = "button66";
            this.button66.Size = new System.Drawing.Size(75, 23);
            this.button66.TabIndex = 25;
            this.button66.Text = "Delete";
            this.button66.UseVisualStyleBackColor = false;
            // 
            // button67
            // 
            this.button67.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button67.BackColor = System.Drawing.SystemColors.ControlText;
            this.button67.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button67.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button67.Location = new System.Drawing.Point(335, 397);
            this.button67.Name = "button67";
            this.button67.Size = new System.Drawing.Size(75, 23);
            this.button67.TabIndex = 24;
            this.button67.Text = "Search";
            this.button67.UseVisualStyleBackColor = false;
            // 
            // button68
            // 
            this.button68.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button68.BackColor = System.Drawing.SystemColors.ControlText;
            this.button68.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button68.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button68.Location = new System.Drawing.Point(438, 397);
            this.button68.Name = "button68";
            this.button68.Size = new System.Drawing.Size(75, 23);
            this.button68.TabIndex = 23;
            this.button68.Text = "Show";
            this.button68.UseVisualStyleBackColor = false;
            // 
            // button69
            // 
            this.button69.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button69.BackColor = System.Drawing.SystemColors.ControlText;
            this.button69.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button69.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button69.Location = new System.Drawing.Point(21, 397);
            this.button69.Name = "button69";
            this.button69.Size = new System.Drawing.Size(75, 23);
            this.button69.TabIndex = 21;
            this.button69.Text = "Insert";
            this.button69.UseVisualStyleBackColor = false;
            // 
            // textBox46
            // 
            this.textBox46.Location = new System.Drawing.Point(118, 91);
            this.textBox46.Name = "textBox46";
            this.textBox46.Size = new System.Drawing.Size(104, 20);
            this.textBox46.TabIndex = 20;
            // 
            // textBox47
            // 
            this.textBox47.Location = new System.Drawing.Point(118, 257);
            this.textBox47.Name = "textBox47";
            this.textBox47.Size = new System.Drawing.Size(107, 20);
            this.textBox47.TabIndex = 16;
            // 
            // label76
            // 
            this.label76.AutoSize = true;
            this.label76.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label76.Location = new System.Drawing.Point(17, 144);
            this.label76.Name = "label76";
            this.label76.Size = new System.Drawing.Size(86, 20);
            this.label76.TabIndex = 12;
            this.label76.Text = "Class Name";
            // 
            // label78
            // 
            this.label78.AutoSize = true;
            this.label78.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label78.Location = new System.Drawing.Point(17, 255);
            this.label78.Name = "label78";
            this.label78.Size = new System.Drawing.Size(89, 20);
            this.label78.TabIndex = 10;
            this.label78.Text = "Fee Amount";
            // 
            // label79
            // 
            this.label79.AutoSize = true;
            this.label79.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label79.Location = new System.Drawing.Point(18, 199);
            this.label79.Name = "label79";
            this.label79.Size = new System.Drawing.Size(58, 20);
            this.label79.TabIndex = 9;
            this.label79.Text = "Session";
            // 
            // textBox48
            // 
            this.textBox48.Location = new System.Drawing.Point(118, 201);
            this.textBox48.Name = "textBox48";
            this.textBox48.Size = new System.Drawing.Size(104, 20);
            this.textBox48.TabIndex = 3;
            // 
            // textBox49
            // 
            this.textBox49.Location = new System.Drawing.Point(118, 146);
            this.textBox49.Name = "textBox49";
            this.textBox49.Size = new System.Drawing.Size(104, 20);
            this.textBox49.TabIndex = 1;
            // 
            // label80
            // 
            this.label80.AutoSize = true;
            this.label80.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label80.Location = new System.Drawing.Point(17, 91);
            this.label80.Name = "label80";
            this.label80.Size = new System.Drawing.Size(59, 20);
            this.label80.TabIndex = 0;
            this.label80.Text = "Class Id";
            // 
            // label74
            // 
            this.label74.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label74.AutoSize = true;
            this.label74.BackColor = System.Drawing.Color.Transparent;
            this.label74.Font = new System.Drawing.Font("Poppins Black", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label74.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label74.Location = new System.Drawing.Point(161, 3);
            this.label74.Name = "label74";
            this.label74.Size = new System.Drawing.Size(218, 48);
            this.label74.TabIndex = 11;
            this.label74.Text = "Student Class";
            this.label74.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // Section
            // 
            this.Section.Controls.Add(this.panel15);
            this.Section.Controls.Add(this.label77);
            this.Section.Location = new System.Drawing.Point(4, 22);
            this.Section.Name = "Section";
            this.Section.Padding = new System.Windows.Forms.Padding(3);
            this.Section.Size = new System.Drawing.Size(577, 497);
            this.Section.TabIndex = 12;
            this.Section.Text = "tabPage1";
            this.Section.UseVisualStyleBackColor = true;
            // 
            // panel15
            // 
            this.panel15.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panel15.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.panel15.Controls.Add(this.textBox13);
            this.panel15.Controls.Add(this.label72);
            this.panel15.Controls.Add(this.textBox10);
            this.panel15.Controls.Add(this.label48);
            this.panel15.Controls.Add(this.textBox9);
            this.panel15.Controls.Add(this.label47);
            this.panel15.Controls.Add(this.button72);
            this.panel15.Controls.Add(this.label81);
            this.panel15.Controls.Add(this.dataGridView11);
            this.panel15.Controls.Add(this.button73);
            this.panel15.Controls.Add(this.button74);
            this.panel15.Controls.Add(this.button75);
            this.panel15.Controls.Add(this.button76);
            this.panel15.Controls.Add(this.button77);
            this.panel15.Controls.Add(this.textBox50);
            this.panel15.Controls.Add(this.label83);
            this.panel15.Controls.Add(this.label84);
            this.panel15.Controls.Add(this.textBox52);
            this.panel15.Controls.Add(this.textBox53);
            this.panel15.Controls.Add(this.label85);
            this.panel15.Location = new System.Drawing.Point(0, 56);
            this.panel15.Name = "panel15";
            this.panel15.Size = new System.Drawing.Size(577, 441);
            this.panel15.TabIndex = 13;
            // 
            // textBox13
            // 
            this.textBox13.Location = new System.Drawing.Point(118, 335);
            this.textBox13.Name = "textBox13";
            this.textBox13.Size = new System.Drawing.Size(104, 20);
            this.textBox13.TabIndex = 42;
            // 
            // label72
            // 
            this.label72.AutoSize = true;
            this.label72.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label72.Location = new System.Drawing.Point(17, 333);
            this.label72.Name = "label72";
            this.label72.Size = new System.Drawing.Size(49, 20);
            this.label72.TabIndex = 41;
            this.label72.Text = "Status";
            // 
            // textBox10
            // 
            this.textBox10.Location = new System.Drawing.Point(118, 286);
            this.textBox10.Name = "textBox10";
            this.textBox10.Size = new System.Drawing.Size(104, 20);
            this.textBox10.TabIndex = 40;
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label48.Location = new System.Drawing.Point(8, 284);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(102, 20);
            this.label48.TabIndex = 39;
            this.label48.Text = "Section Name";
            // 
            // textBox9
            // 
            this.textBox9.Location = new System.Drawing.Point(118, 181);
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new System.Drawing.Size(104, 20);
            this.textBox9.TabIndex = 38;
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label47.Location = new System.Drawing.Point(17, 179);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(77, 20);
            this.label47.TabIndex = 37;
            this.label47.Text = "Teacher Id";
            // 
            // button72
            // 
            this.button72.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button72.BackColor = System.Drawing.SystemColors.ControlText;
            this.button72.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button72.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button72.Location = new System.Drawing.Point(438, 349);
            this.button72.Name = "button72";
            this.button72.Size = new System.Drawing.Size(75, 23);
            this.button72.TabIndex = 36;
            this.button72.Text = "Back";
            this.button72.UseVisualStyleBackColor = false;
            this.button72.Click += new System.EventHandler(this.button72_Click);
            // 
            // label81
            // 
            this.label81.AutoSize = true;
            this.label81.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label81.Location = new System.Drawing.Point(374, 69);
            this.label81.Name = "label81";
            this.label81.Size = new System.Drawing.Size(80, 20);
            this.label81.TabIndex = 33;
            this.label81.Text = "Table View";
            // 
            // dataGridView11
            // 
            this.dataGridView11.BackgroundColor = System.Drawing.SystemColors.Control;
            this.dataGridView11.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView11.Location = new System.Drawing.Point(257, 125);
            this.dataGridView11.Name = "dataGridView11";
            this.dataGridView11.Size = new System.Drawing.Size(310, 179);
            this.dataGridView11.TabIndex = 32;
            // 
            // button73
            // 
            this.button73.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button73.BackColor = System.Drawing.SystemColors.ControlText;
            this.button73.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button73.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button73.Location = new System.Drawing.Point(132, 397);
            this.button73.Name = "button73";
            this.button73.Size = new System.Drawing.Size(75, 23);
            this.button73.TabIndex = 26;
            this.button73.Text = "Update";
            this.button73.UseVisualStyleBackColor = false;
            // 
            // button74
            // 
            this.button74.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button74.BackColor = System.Drawing.SystemColors.ControlText;
            this.button74.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button74.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button74.Location = new System.Drawing.Point(238, 397);
            this.button74.Name = "button74";
            this.button74.Size = new System.Drawing.Size(75, 23);
            this.button74.TabIndex = 25;
            this.button74.Text = "Delete";
            this.button74.UseVisualStyleBackColor = false;
            // 
            // button75
            // 
            this.button75.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button75.BackColor = System.Drawing.SystemColors.ControlText;
            this.button75.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button75.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button75.Location = new System.Drawing.Point(335, 397);
            this.button75.Name = "button75";
            this.button75.Size = new System.Drawing.Size(75, 23);
            this.button75.TabIndex = 24;
            this.button75.Text = "Search";
            this.button75.UseVisualStyleBackColor = false;
            // 
            // button76
            // 
            this.button76.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button76.BackColor = System.Drawing.SystemColors.ControlText;
            this.button76.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button76.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button76.Location = new System.Drawing.Point(438, 397);
            this.button76.Name = "button76";
            this.button76.Size = new System.Drawing.Size(75, 23);
            this.button76.TabIndex = 23;
            this.button76.Text = "Show";
            this.button76.UseVisualStyleBackColor = false;
            // 
            // button77
            // 
            this.button77.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button77.BackColor = System.Drawing.SystemColors.ControlText;
            this.button77.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button77.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button77.Location = new System.Drawing.Point(21, 397);
            this.button77.Name = "button77";
            this.button77.Size = new System.Drawing.Size(75, 23);
            this.button77.TabIndex = 21;
            this.button77.Text = "Insert";
            this.button77.UseVisualStyleBackColor = false;
            // 
            // textBox50
            // 
            this.textBox50.Location = new System.Drawing.Point(118, 70);
            this.textBox50.Name = "textBox50";
            this.textBox50.Size = new System.Drawing.Size(104, 20);
            this.textBox50.TabIndex = 20;
            // 
            // label83
            // 
            this.label83.AutoSize = true;
            this.label83.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label83.Location = new System.Drawing.Point(17, 231);
            this.label83.Name = "label83";
            this.label83.Size = new System.Drawing.Size(85, 20);
            this.label83.TabIndex = 10;
            this.label83.Text = "Std Reg No";
            // 
            // label84
            // 
            this.label84.AutoSize = true;
            this.label84.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label84.Location = new System.Drawing.Point(17, 125);
            this.label84.Name = "label84";
            this.label84.Size = new System.Drawing.Size(59, 20);
            this.label84.TabIndex = 9;
            this.label84.Text = "Class Id";
            // 
            // textBox52
            // 
            this.textBox52.Location = new System.Drawing.Point(118, 233);
            this.textBox52.Name = "textBox52";
            this.textBox52.Size = new System.Drawing.Size(104, 20);
            this.textBox52.TabIndex = 3;
            // 
            // textBox53
            // 
            this.textBox53.Location = new System.Drawing.Point(118, 127);
            this.textBox53.Name = "textBox53";
            this.textBox53.Size = new System.Drawing.Size(104, 20);
            this.textBox53.TabIndex = 1;
            // 
            // label85
            // 
            this.label85.AutoSize = true;
            this.label85.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label85.Location = new System.Drawing.Point(17, 69);
            this.label85.Name = "label85";
            this.label85.Size = new System.Drawing.Size(75, 20);
            this.label85.TabIndex = 0;
            this.label85.Text = "Section Id";
            // 
            // label77
            // 
            this.label77.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label77.AutoSize = true;
            this.label77.BackColor = System.Drawing.Color.Transparent;
            this.label77.Font = new System.Drawing.Font("Poppins Black", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label77.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label77.Location = new System.Drawing.Point(150, 5);
            this.label77.Name = "label77";
            this.label77.Size = new System.Drawing.Size(246, 48);
            this.label77.TabIndex = 12;
            this.label77.Text = "Student Section";
            this.label77.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // timer2
            // 
            this.timer2.Tick += new System.EventHandler(this.timer2_Tick);
            // 
            // studentTableAdapter
            // 
            this.studentTableAdapter.ClearBeforeFill = true;
            // 
            // teacherTableAdapter
            // 
            this.teacherTableAdapter.ClearBeforeFill = true;
            // 
            // button1
            // 
            this.button1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button1.BackColor = System.Drawing.SystemColors.ControlText;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button1.Location = new System.Drawing.Point(335, 344);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(102, 23);
            this.button1.TabIndex = 38;
            this.button1.Text = "Load Report";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ClientSize = new System.Drawing.Size(756, 496);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.panel1);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.tabControl1.ResumeLayout(false);
            this.Homepage.ResumeLayout(false);
            this.Homepage.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.StudentPortal.ResumeLayout(false);
            this.StudentPortal.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.studentBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dBFinalProjectDataSet8)).EndInit();
            this.TeacherPortal.ResumeLayout(false);
            this.TeacherPortal.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.teacherBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dBFinalProjectDataSet9)).EndInit();
            this.CoursePortal.ResumeLayout(false);
            this.CoursePortal.PerformLayout();
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).EndInit();
            this.ExamPortal.ResumeLayout(false);
            this.ExamPortal.PerformLayout();
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView4)).EndInit();
            this.TeacherSalary.ResumeLayout(false);
            this.TeacherSalary.PerformLayout();
            this.panel9.ResumeLayout(false);
            this.panel9.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView5)).EndInit();
            this.TeacherAttendance.ResumeLayout(false);
            this.TeacherAttendance.PerformLayout();
            this.panel10.ResumeLayout(false);
            this.panel10.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView6)).EndInit();
            this.StudentFee.ResumeLayout(false);
            this.StudentFee.PerformLayout();
            this.panel11.ResumeLayout(false);
            this.panel11.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView7)).EndInit();
            this.StudentResult.ResumeLayout(false);
            this.StudentResult.PerformLayout();
            this.panel12.ResumeLayout(false);
            this.panel12.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView8)).EndInit();
            this.StudentAttendance.ResumeLayout(false);
            this.StudentAttendance.PerformLayout();
            this.panel13.ResumeLayout(false);
            this.panel13.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView9)).EndInit();
            this.StudentClass.ResumeLayout(false);
            this.StudentClass.PerformLayout();
            this.panel14.ResumeLayout(false);
            this.panel14.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView10)).EndInit();
            this.Section.ResumeLayout(false);
            this.Section.PerformLayout();
            this.panel15.ResumeLayout(false);
            this.panel15.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView11)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage Homepage;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.TabPage StudentPortal;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.TextBox textBox11;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.TabPage TeacherPortal;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.DateTimePicker dateTimePicker2;
        private System.Windows.Forms.Button button18;
        private System.Windows.Forms.Button button19;
        private System.Windows.Forms.Button button20;
        private System.Windows.Forms.Button button21;
        private System.Windows.Forms.Button button22;
        private System.Windows.Forms.Button button23;
        private System.Windows.Forms.Button button24;
        private System.Windows.Forms.TextBox textBox12;
        private System.Windows.Forms.TextBox textBox14;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.TextBox textBox15;
        private System.Windows.Forms.TextBox textBox16;
        private System.Windows.Forms.TextBox textBox17;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.TabPage CoursePortal;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.DataGridView dataGridView3;
        private System.Windows.Forms.Button button25;
        private System.Windows.Forms.Button button26;
        private System.Windows.Forms.Button button27;
        private System.Windows.Forms.Button button28;
        private System.Windows.Forms.Button button29;
        private System.Windows.Forms.TextBox textBox19;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.TextBox textBox23;
        private System.Windows.Forms.TextBox textBox24;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Button button30;
        private System.Windows.Forms.TabPage ExamPortal;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.DataGridView dataGridView4;
        private System.Windows.Forms.Button button16;
        private System.Windows.Forms.Button button17;
        private System.Windows.Forms.Button button31;
        private System.Windows.Forms.Button button32;
        private System.Windows.Forms.Button button33;
        private System.Windows.Forms.TextBox textBox18;
        private System.Windows.Forms.TextBox textBox20;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.TextBox textBox25;
        private System.Windows.Forms.TextBox textBox26;
        private System.Windows.Forms.TextBox textBox27;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.TabPage TeacherSalary;
        private System.Windows.Forms.TabPage TeacherAttendance;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.DataGridView dataGridView5;
        private System.Windows.Forms.DateTimePicker dateTimePicker3;
        private System.Windows.Forms.Button button36;
        private System.Windows.Forms.Button button37;
        private System.Windows.Forms.Button button38;
        private System.Windows.Forms.Button button39;
        private System.Windows.Forms.Button button40;
        private System.Windows.Forms.TextBox textBox29;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.TextBox textBox33;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.DataGridView dataGridView6;
        private System.Windows.Forms.DateTimePicker dateTimePicker4;
        private System.Windows.Forms.Button button34;
        private System.Windows.Forms.Button button35;
        private System.Windows.Forms.Button button41;
        private System.Windows.Forms.Button button42;
        private System.Windows.Forms.Button button43;
        private System.Windows.Forms.TextBox textBox28;
        private System.Windows.Forms.TextBox textBox30;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Button button44;
        private System.Windows.Forms.Button button45;
        private System.Windows.Forms.TabPage StudentFee;
        private System.Windows.Forms.TabPage StudentResult;
        private System.Windows.Forms.TabPage StudentAttendance;
        private System.Windows.Forms.TabPage StudentClass;
        private System.Windows.Forms.Label label62;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.DateTimePicker dateTimePicker6;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.DataGridView dataGridView7;
        private System.Windows.Forms.DateTimePicker dateTimePicker5;
        private System.Windows.Forms.Button button50;
        private System.Windows.Forms.Button button51;
        private System.Windows.Forms.Button button52;
        private System.Windows.Forms.Button button53;
        private System.Windows.Forms.Button button54;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.TextBox textBox40;
        private System.Windows.Forms.Label label61;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.DataGridView dataGridView8;
        private System.Windows.Forms.Button button55;
        private System.Windows.Forms.Button button56;
        private System.Windows.Forms.Button button57;
        private System.Windows.Forms.Button button58;
        private System.Windows.Forms.Button button59;
        private System.Windows.Forms.TextBox textBox36;
        private System.Windows.Forms.TextBox textBox37;
        private System.Windows.Forms.TextBox textBox39;
        private System.Windows.Forms.Label label63;
        private System.Windows.Forms.Label label65;
        private System.Windows.Forms.Label label66;
        private System.Windows.Forms.Label label67;
        private System.Windows.Forms.Label label68;
        private System.Windows.Forms.TextBox textBox41;
        private System.Windows.Forms.TextBox textBox42;
        private System.Windows.Forms.TextBox textBox43;
        private System.Windows.Forms.Label label69;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.Panel panel13;
        private System.Windows.Forms.Button button46;
        private System.Windows.Forms.Label label64;
        private System.Windows.Forms.Label label70;
        private System.Windows.Forms.DataGridView dataGridView9;
        private System.Windows.Forms.DateTimePicker dateTimePicker7;
        private System.Windows.Forms.Button button47;
        private System.Windows.Forms.Button button48;
        private System.Windows.Forms.Button button49;
        private System.Windows.Forms.Button button60;
        private System.Windows.Forms.Button button61;
        private System.Windows.Forms.Label label71;
        private System.Windows.Forms.Button button62;
        private System.Windows.Forms.Button button63;
        private System.Windows.Forms.Label label74;
        private System.Windows.Forms.Panel panel14;
        private System.Windows.Forms.Button button64;
        private System.Windows.Forms.Label label75;
        private System.Windows.Forms.DataGridView dataGridView10;
        private System.Windows.Forms.Button button65;
        private System.Windows.Forms.Button button66;
        private System.Windows.Forms.Button button67;
        private System.Windows.Forms.Button button68;
        private System.Windows.Forms.Button button69;
        private System.Windows.Forms.TextBox textBox46;
        private System.Windows.Forms.TextBox textBox47;
        private System.Windows.Forms.Label label76;
        private System.Windows.Forms.Label label78;
        private System.Windows.Forms.Label label79;
        private System.Windows.Forms.TextBox textBox48;
        private System.Windows.Forms.TextBox textBox49;
        private System.Windows.Forms.Label label80;
        private System.Windows.Forms.Button button70;
        private System.Windows.Forms.TabPage Section;
        private System.Windows.Forms.Label label77;
        private System.Windows.Forms.Panel panel15;
        private System.Windows.Forms.Button button72;
        private System.Windows.Forms.Label label81;
        private System.Windows.Forms.DataGridView dataGridView11;
        private System.Windows.Forms.Button button73;
        private System.Windows.Forms.Button button74;
        private System.Windows.Forms.Button button75;
        private System.Windows.Forms.Button button76;
        private System.Windows.Forms.Button button77;
        private System.Windows.Forms.TextBox textBox50;
        private System.Windows.Forms.Label label83;
        private System.Windows.Forms.Label label84;
        private System.Windows.Forms.TextBox textBox52;
        private System.Windows.Forms.TextBox textBox53;
        private System.Windows.Forms.Label label85;
        private System.Windows.Forms.Button button71;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label labelTime;
        private System.Windows.Forms.Timer timer2;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.ComboBox comboBox3;
        private System.Windows.Forms.ComboBox comboBox4;
        private System.Windows.Forms.Label label73;
        private System.Windows.Forms.ComboBox comboBox6;
        private System.Windows.Forms.ComboBox comboBox5;
        private System.Windows.Forms.ComboBox comboBox8;
        private System.Windows.Forms.ComboBox comboBox7;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox comboBox10;
        private System.Windows.Forms.ComboBox comboBox9;
        private DBFinalProjectDataSet8 dBFinalProjectDataSet8;
        private System.Windows.Forms.BindingSource studentBindingSource;
        private DBFinalProjectDataSet8TableAdapters.StudentTableAdapter studentTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn regNoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn firstNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn lastNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn emailDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn contactDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dOBDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn statusDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn genderDataGridViewTextBoxColumn;
        private DBFinalProjectDataSet9 dBFinalProjectDataSet9;
        private System.Windows.Forms.BindingSource teacherBindingSource;
        private DBFinalProjectDataSet9TableAdapters.TeacherTableAdapter teacherTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn tIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn firstNameDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn lastNameDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn contactDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn emailDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn genderDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dOBDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn statusDataGridViewTextBoxColumn1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.TextBox textBox13;
        private System.Windows.Forms.Label label72;
        private System.Windows.Forms.TextBox textBox10;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.Label label82;
        private System.Windows.Forms.TextBox textBox21;
        private System.Windows.Forms.TextBox textBox31;
        private System.Windows.Forms.Label label87;
        private System.Windows.Forms.TextBox textBox22;
        private System.Windows.Forms.Label label86;
        private System.Windows.Forms.Button button1;
    }
}

